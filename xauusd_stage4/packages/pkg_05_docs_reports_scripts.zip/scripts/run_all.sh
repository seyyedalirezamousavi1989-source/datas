#!/usr/bin/env bash
# Full reproducible run (plain Python 3 + pandas + numpy; no network).
set -euo pipefail
cd "$(dirname "$0")/.."
python3 scripts/s01_clean_validate.py
python3 scripts/s02_build_features.py
python3 scripts/s03_mtf_join.py
python3 scripts/s04_validate_outputs.py
python3 scripts/s06_package.py data
python3 scripts/s05_make_manifest_docs.py
python3 scripts/s06_package.py docs
