"""Smart Money Concepts (SMC) features - explicit, causal, reproducible rules.

Everything is evaluated bar by bar in a single forward pass. At bar t the code may read
open/high/low/close/ATR of bars <= t only. The only vectorised pre-computation (swing
candidates) evaluates a window that ends at bar i+R and its result is *used* at bar t=i+R,
so a swing is never visible before its R confirmation candles have closed.
These are heuristic *interpretations* of price action (especially Order Blocks); they are
not objectively verified market facts and carry no implied profitability.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from numpy.lib.stride_tricks import sliding_window_view

import config as C

NAN = float("nan")
EVT = {"none": 0, "bos_bull": 1, "bos_bear": 2, "choch_bull": 3, "choch_bear": 4}


def _swings(h, l, L, R):
    n = len(h)
    sh = np.zeros(n, dtype=bool)
    sl = np.zeros(n, dtype=bool)
    W = L + R + 1
    if n >= W:
        hw = sliding_window_view(h, W)
        lw = sliding_window_view(l, W)
        ch = (hw[:, L] > hw[:, :L].max(axis=1)) & (hw[:, L] >= hw[:, L + 1:].max(axis=1))
        cl = (lw[:, L] < lw[:, :L].min(axis=1)) & (lw[:, L] <= lw[:, L + 1:].min(axis=1))
        sh[L:L + len(ch)] = ch
        sl[L:L + len(cl)] = cl
    return sh, sl


def _nearest_bull(zs, c, a, t):
    """Nearest active bullish zone: smallest distance from close down to the zone TOP (0 if inside)."""
    best, bd = None, 1e300
    for z in zs:
        d = c - z[1]
        if d < 0.0:
            d = 0.0
        if d <= bd:
            bd, best = d, z
    return best, bd


def _nearest_bear(zs, c, a, t):
    best, bd = None, 1e300
    for z in zs:
        d = z[0] - c
        if d < 0.0:
            d = 0.0
        if d <= bd:
            bd, best = d, z
    return best, bd


def compute_smc(df, tf, P=None):
    P = P or C.SMC
    L, R = P["swing_left"], P["swing_right"]
    n = len(df)
    o = df["open"].to_numpy(float)
    h = df["high"].to_numpy(float)
    l = df["low"].to_numpy(float)
    c = df["close"].to_numpy(float)
    atr = df["atr_14"].to_numpy(float)
    atr_prev = np.concatenate([[NAN], atr[:-1]])
    rng = h - l
    body = c - o
    with np.errstate(divide="ignore", invalid="ignore"):
        body_ratio = np.where(rng > 0, np.abs(body) / rng, 0.0)
        disp_strength = rng / atr_prev
        disp_ok = (disp_strength >= P["disp_range_atr"]) & (body_ratio >= P["disp_body_ratio"])
    disp_dir = np.where(disp_ok, np.sign(body), 0).astype(np.int8)
    sw_h, sw_l = _swings(h, l, L, R)

    f = lambda: np.full(n, NAN)
    i8 = lambda: np.zeros(n, dtype=np.int8)
    o_ = {k: i8() for k in [
        "swing_high_confirmed", "swing_low_confirmed", "trend_state", "bos_bull", "bos_bear", "choch_bull", "choch_bear",
        "struct_last_event", "bsl_sweep", "ssl_sweep", "bsl_sweep_eq", "ssl_sweep_eq", "eqh_formed", "eql_formed",
        "pd_valid", "pd_zone", "bsl_n_active", "ssl_n_active"]}
    fl = {k: f() for k in [
        "last_swing_high", "last_swing_low", "bars_since_swing_high", "bars_since_swing_low", "struct_break_level",
        "bars_since_struct_event", "bsl_sweep_depth_atr", "ssl_sweep_depth_atr", "dist_bsl_atr", "dist_ssl_atr",
        "dist_eqh_atr", "dist_eql_atr", "pd_pos", "pd_equilibrium", "disp_strength_atr"]}
    zone_names = ["fvg_bull", "fvg_bear", "ob_bull", "ob_bear"]
    zi = {z: {k: i8() for k in ["formed", "n_active", "touched_now", "invalidated_now", "in_zone"]} for z in zone_names}
    zf = {z: {k: f() for k in ["top", "bottom", "dist_atr", "age", "touches"]} for z in zone_names}
    fvg_size = {"fvg_bull": f(), "fvg_bear": f()}
    # zone lists: [bottom, top, created_idx, touches]
    Z = {z: [] for z in zone_names}
    bsl, ssl = [], []                      # liquidity pools: [level, swing_idx, is_equal]
    lsh = lsl = NAN
    lsh_i = lsl_i = -1
    sh_broken = sl_broken = True
    trend = 0
    last_evt, last_evt_i = 0, -1
    fvg_min, zmax = P["fvg_min_atr"], P["zone_max_age"]
    eq_tol, cap_l, lmax = P["eq_tol_atr"], P["liq_cap"], P["liq_max_age"]
    caps = {"fvg_bull": P["fvg_cap"], "fvg_bear": P["fvg_cap"], "ob_bull": P["ob_cap"], "ob_bear": P["ob_cap"]}
    band = P["pd_eq_band"]
    obl = P["ob_lookback"]

    for t in range(n):
        a = atr[t]
        ha, la, ca = h[t], l[t], c[t]
        has_a = a == a  # not NaN

        # 1) swing confirmation: candidate bar i = t-R, its R right-hand bars have now closed
        i = t - R
        if i >= L:
            if sw_h[i]:
                lv = h[i]
                eq = False
                if has_a:
                    tol = eq_tol * a
                    for e in bsl:
                        if abs(e[0] - lv) <= tol:
                            e[2] = True
                            eq = True
                bsl.append([lv, i, eq])
                if len(bsl) > cap_l:
                    del bsl[0]
                lsh, lsh_i, sh_broken = lv, i, False
                o_["swing_high_confirmed"][t] = 1
                if eq:
                    o_["eqh_formed"][t] = 1
            if sw_l[i]:
                lv = l[i]
                eq = False
                if has_a:
                    tol = eq_tol * a
                    for e in ssl:
                        if abs(e[0] - lv) <= tol:
                            e[2] = True
                            eq = True
                ssl.append([lv, i, eq])
                if len(ssl) > cap_l:
                    del ssl[0]
                lsl, lsl_i, sl_broken = lv, i, False
                o_["swing_low_confirmed"][t] = 1
                if eq:
                    o_["eql_formed"][t] = 1

        # 2a) liquidity sweeps (wick beyond an unbroken confirmed swing level, close back inside)
        if bsl:
            keep, swept, sw_eq, outer = [], False, False, -1e300
            for e in bsl:
                if t - e[1] > lmax:
                    continue
                if ha > e[0]:
                    if ca <= e[0]:
                        swept = True
                        sw_eq = sw_eq or e[2]
                        if e[0] > outer:
                            outer = e[0]
                    # close above the level -> level is "broken", not swept
                else:
                    keep.append(e)
            bsl = keep
            if swept:
                o_["bsl_sweep"][t] = 1
                o_["bsl_sweep_eq"][t] = 1 if sw_eq else 0
                if has_a and a > 0:
                    fl["bsl_sweep_depth_atr"][t] = (ha - outer) / a
        if ssl:
            keep, swept, sw_eq, outer = [], False, False, 1e300
            for e in ssl:
                if t - e[1] > lmax:
                    continue
                if la < e[0]:
                    if ca >= e[0]:
                        swept = True
                        sw_eq = sw_eq or e[2]
                        if e[0] < outer:
                            outer = e[0]
                else:
                    keep.append(e)
            ssl = keep
            if swept:
                o_["ssl_sweep"][t] = 1
                o_["ssl_sweep_eq"][t] = 1 if sw_eq else 0
                if has_a and a > 0:
                    fl["ssl_sweep_depth_atr"][t] = (outer - la) / a

        # 2b) structure break: CLOSE beyond the last confirmed, not-yet-broken swing level
        bull_break = bear_break = False
        if (not sh_broken) and ca > lsh:
            kind = "bos_bull" if trend >= 0 else "choch_bull"
            o_[kind][t] = 1
            fl["struct_break_level"][t] = lsh
            sh_broken, trend, bull_break = True, 1, True
            last_evt, last_evt_i = EVT[kind], t
        elif (not sl_broken) and ca < lsl:
            kind = "bos_bear" if trend <= 0 else "choch_bear"
            o_[kind][t] = 1
            fl["struct_break_level"][t] = lsl
            sl_broken, trend, bear_break = True, -1, True
            last_evt, last_evt_i = EVT[kind], t

        # 3) lifecycle of zones that existed BEFORE this bar
        for z in zone_names:
            zs = Z[z]
            if not zs:
                continue
            bull = z.endswith("bull")
            keep, touched, inval = [], False, False
            for zz in zs:
                if t - zz[2] > zmax:
                    continue
                if bull:
                    if ca < zz[0]:
                        inval = True
                        continue
                    if la <= zz[1] and ha >= zz[0]:
                        zz[3] += 1
                        touched = True
                else:
                    if ca > zz[1]:
                        inval = True
                        continue
                    if ha >= zz[0] and la <= zz[1]:
                        zz[3] += 1
                        touched = True
                keep.append(zz)
            Z[z] = keep
            zi[z]["touched_now"][t] = 1 if touched else 0
            zi[z]["invalidated_now"][t] = 1 if inval else 0

        # 4) new FVGs (3-candle imbalance completed at bar t)
        if t >= 2 and has_a:
            if la > h[t - 2]:
                size = la - h[t - 2]
                if size >= fvg_min * a:
                    Z["fvg_bull"].append([h[t - 2], la, t, 0])
                    zi["fvg_bull"]["formed"][t] = 1
                    fvg_size["fvg_bull"][t] = size / a
                    if len(Z["fvg_bull"]) > caps["fvg_bull"]:
                        del Z["fvg_bull"][0]
            if ha < l[t - 2]:
                size = l[t - 2] - ha
                if size >= fvg_min * a:
                    Z["fvg_bear"].append([ha, l[t - 2], t, 0])
                    zi["fvg_bear"]["formed"][t] = 1
                    fvg_size["fvg_bear"][t] = size / a
                    if len(Z["fvg_bear"]) > caps["fvg_bear"]:
                        del Z["fvg_bear"][0]

        # 5) new Order Blocks: last opposite candle (<= ob_lookback bars back) before the impulse leg
        #    that produced a BOS/CHOCH, only if that leg contains a displacement candle in the break direction.
        if bull_break or bear_break:
            lim = max(t - obl, 0)
            k = t - 1
            if bull_break:
                while k >= lim and not (c[k] < o[k]):
                    k -= 1
                if k >= lim and (disp_dir[k + 1:t + 1] == 1).any() and not any(zz[2] == k for zz in Z["ob_bull"]):
                    Z["ob_bull"].append([l[k], h[k], k, 0])
                    zi["ob_bull"]["formed"][t] = 1
                    if len(Z["ob_bull"]) > caps["ob_bull"]:
                        del Z["ob_bull"][0]
            else:
                while k >= lim and not (c[k] > o[k]):
                    k -= 1
                if k >= lim and (disp_dir[k + 1:t + 1] == -1).any() and not any(zz[2] == k for zz in Z["ob_bear"]):
                    Z["ob_bear"].append([l[k], h[k], k, 0])
                    zi["ob_bear"]["formed"][t] = 1
                    if len(Z["ob_bear"]) > caps["ob_bear"]:
                        del Z["ob_bear"][0]

        # 6) snapshot of state at the close of bar t
        o_["trend_state"][t] = trend
        o_["struct_last_event"][t] = last_evt
        if last_evt_i >= 0:
            fl["bars_since_struct_event"][t] = t - last_evt_i
        if lsh == lsh:
            fl["last_swing_high"][t] = lsh
            fl["bars_since_swing_high"][t] = t - lsh_i
        if lsl == lsl:
            fl["last_swing_low"][t] = lsl
            fl["bars_since_swing_low"][t] = t - lsl_i
        if has_a and a > 0:
            fl["disp_strength_atr"][t] = disp_strength[t] if disp_strength[t] == disp_strength[t] else NAN
        o_["bsl_n_active"][t] = len(bsl)
        o_["ssl_n_active"][t] = len(ssl)
        if bsl and has_a and a > 0:
            fl["dist_bsl_atr"][t] = (min(e[0] for e in bsl) - ca) / a
            eqs = [e[0] for e in bsl if e[2]]
            if eqs:
                fl["dist_eqh_atr"][t] = (min(eqs) - ca) / a
        if ssl and has_a and a > 0:
            fl["dist_ssl_atr"][t] = (ca - max(e[0] for e in ssl)) / a
            eqs = [e[0] for e in ssl if e[2]]
            if eqs:
                fl["dist_eql_atr"][t] = (ca - max(eqs)) / a
        if lsh == lsh and lsl == lsl and lsh > lsl:
            pos = (ca - lsl) / (lsh - lsl)
            fl["pd_pos"][t] = pos
            fl["pd_equilibrium"][t] = 0.5 * (lsh + lsl)
            o_["pd_valid"][t] = 1
            o_["pd_zone"][t] = 1 if pos > 0.5 + band else (-1 if pos < 0.5 - band else 0)
        for z in zone_names:
            zs = Z[z]
            zi[z]["n_active"][t] = len(zs)
            if zs:
                best, d = (_nearest_bull if z.endswith("bull") else _nearest_bear)(zs, ca, a, t)
                zf[z]["top"][t] = best[1]
                zf[z]["bottom"][t] = best[0]
                zf[z]["age"][t] = t - best[2]
                zf[z]["touches"][t] = best[3]
                if has_a and a > 0:
                    zf[z]["dist_atr"][t] = d / a
                zi[z]["in_zone"][t] = 1 if (d == 0.0 and best[0] <= ca <= best[1]) else 0

    out = {}
    out.update(o_)
    out.update(fl)
    out["disp_dir"] = disp_dir
    for z in zone_names:
        for k, v in zi[z].items():
            out[f"{z}_{k}"] = v
        for k, v in zf[z].items():
            out[f"{z}_{k}" if k != "dist_atr" else f"{z}_dist_atr"] = v
    out["fvg_bull_size_atr"] = fvg_size["fvg_bull"]
    out["fvg_bear_size_atr"] = fvg_size["fvg_bear"]
    with np.errstate(invalid="ignore", divide="ignore"):
        out["dist_last_swing_high_atr"] = (fl["last_swing_high"] - c) / atr
        out["dist_last_swing_low_atr"] = (c - fl["last_swing_low"]) / atr
    res = pd.DataFrame(out, index=df.index).replace([np.inf, -np.inf], np.nan)
    return res, smc_definitions(P, tf)


def smc_definitions(P, tf):
    L, R = P["swing_left"], P["swing_right"]
    d = {
        "swing_high_confirmed": f"EVENT (1 at the confirmation bar). A swing high at bar i exists if high[i] > max(high[i-{L}..i-1]) and high[i] >= max(high[i+1..i+{R}]). "
                                f"It is only flagged at bar i+{R} (all {R} confirmation candles closed). The swing bar itself is i = t-{R}.",
        "swing_low_confirmed": f"EVENT. Mirror of swing_high_confirmed: low[i] < min(low[i-{L}..i-1]) and low[i] <= min(low[i+1..i+{R}]), flagged at bar i+{R}.",
        "last_swing_high": "Level of the most recent CONFIRMED swing high (carried forward; NaN before the first one). Remains after being broken until a newer swing high is confirmed.",
        "last_swing_low": "Level of the most recent confirmed swing low (carried forward).",
        "bars_since_swing_high": "t - index of the swing candle (not of its confirmation) of last_swing_high.",
        "bars_since_swing_low": "t - index of the swing candle of last_swing_low.",
        "dist_last_swing_high_atr": "(last_swing_high - close) / ATR14.",
        "dist_last_swing_low_atr": "(close - last_swing_low) / ATR14.",
        "trend_state": "Market-structure state after the latest break: +1 bullish (last break was upward), -1 bearish, 0 before the first break.",
        "bos_bull": "EVENT. Bar CLOSES above the last confirmed, not-yet-broken swing high while trend_state >= 0 (continuation; the very first break from state 0 is also labelled BOS). Each swing level can be broken once.",
        "bos_bear": "EVENT. Bar closes below the last confirmed, not-yet-broken swing low while trend_state <= 0.",
        "choch_bull": "EVENT. Bar closes above the last confirmed, not-yet-broken swing high while trend_state == -1 (first break against a bearish structure = Change of Character).",
        "choch_bear": "EVENT. Bar closes below the last confirmed, not-yet-broken swing low while trend_state == +1.",
        "struct_break_level": "Price level broken at this bar's BOS/CHOCH (NaN when no break).",
        "struct_last_event": "Carry-forward code of the latest structure event: 0 none, 1 BOS bull, 2 BOS bear, 3 CHOCH bull, 4 CHOCH bear.",
        "bars_since_struct_event": "Bars since the latest BOS/CHOCH (NaN before the first).",
        "bsl_sweep": f"EVENT. Buy-side liquidity sweep: bar high exceeds at least one active (confirmed, unbroken, age<={P['liq_max_age']}) swing-high pool but the bar CLOSES at or below that level. Each pool is consumed on first excursion (swept or broken).",
        "ssl_sweep": "EVENT. Sell-side liquidity sweep: bar low goes below an active swing-low pool but the bar closes at or above it.",
        "bsl_sweep_eq": "1 if a swept buy-side pool was part of an equal-highs cluster.",
        "ssl_sweep_eq": "1 if a swept sell-side pool was part of an equal-lows cluster.",
        "bsl_sweep_depth_atr": "(bar high - outermost swept swing-high level) / ATR14 at a bsl_sweep bar, else NaN.",
        "ssl_sweep_depth_atr": "(outermost swept swing-low level - bar low) / ATR14 at an ssl_sweep bar, else NaN.",
        "bsl_n_active": f"Number of active unswept swing-high pools (max {P['liq_cap']}).",
        "ssl_n_active": f"Number of active unswept swing-low pools (max {P['liq_cap']}).",
        "dist_bsl_atr": "(lowest active swing-high pool - close) / ATR14: distance to the nearest buy-side liquidity above price (always >= 0 by construction).",
        "dist_ssl_atr": "(close - highest active swing-low pool) / ATR14: distance to the nearest sell-side liquidity below price.",
        "eqh_formed": f"EVENT. A newly confirmed swing high lies within {P['eq_tol_atr']} x ATR14 (at confirmation) of an active unswept swing high = Equal Highs.",
        "eql_formed": f"EVENT. A newly confirmed swing low within {P['eq_tol_atr']} x ATR14 of an active unswept swing low = Equal Lows.",
        "dist_eqh_atr": "(nearest active equal-highs pool - close) / ATR14; NaN if none.",
        "dist_eql_atr": "(close - nearest active equal-lows pool) / ATR14; NaN if none.",
        "pd_valid": "1 if both last_swing_high and last_swing_low exist and last_swing_high > last_swing_low.",
        "pd_equilibrium": "(last_swing_high + last_swing_low) / 2 when pd_valid.",
        "pd_pos": "(close - last_swing_low) / (last_swing_high - last_swing_low) when pd_valid; <0 or >1 means price is outside the last confirmed range.",
        "pd_zone": f"+1 premium (pd_pos > {0.5 + P['pd_eq_band']:.2f}), -1 discount (pd_pos < {0.5 - P['pd_eq_band']:.2f}), 0 equilibrium band or pd_valid==0.",
        "disp_dir": f"Displacement candle: +1/-1 if range >= {P['disp_range_atr']} x ATR14[t-1] AND |body|/range >= {P['disp_body_ratio']} (sign = candle direction), else 0.",
        "disp_strength_atr": "range / ATR14[t-1] for every bar (displacement is the subset exceeding the threshold).",
        "fvg_bull_size_atr": "At a bullish-FVG formation bar: gap size / ATR14; else NaN.",
        "fvg_bear_size_atr": "At a bearish-FVG formation bar: gap size / ATR14; else NaN.",
    }
    z_txt = {
        "fvg_bull": (f"Bullish FVG: at bar t, low[t] > high[t-2]; zone = [high[t-2], low[t]]; created at close of t only if size >= {P['fvg_min_atr']} x ATR14[t]. "
                     "Touch: a later bar's range overlaps the zone (low <= top). Invalidated: a later bar CLOSES below the zone bottom. "
                     f"Expired after {P['zone_max_age']} bars. Max {P['fvg_cap']} active zones (oldest dropped)."),
        "fvg_bear": (f"Bearish FVG: high[t] < low[t-2]; zone = [high[t], low[t-2]]; same size filter. Touch: range overlaps zone (high >= bottom). "
                     f"Invalidated: a later bar CLOSES above the zone top. Expired after {P['zone_max_age']} bars."),
        "ob_bull": (f"Bullish Order Block (HEURISTIC): when a bullish BOS/CHOCH closes at bar t, take the last bearish candle (close<open) within {P['ob_lookback']} bars before t; "
                    f"zone = its full range [low, high]; created only if a bullish displacement candle lies between that candle and t. "
                    f"Touch: later range overlaps zone. Invalidated: later CLOSE below zone low. Expired after {P['zone_max_age']} bars. Max {P['ob_cap']} active."),
        "ob_bear": (f"Bearish Order Block (HEURISTIC): at a bearish BOS/CHOCH take the last bullish candle within {P['ob_lookback']} bars; zone = its range; "
                    "requires a bearish displacement candle in the leg. Invalidated: later CLOSE above zone high."),
    }
    for z, txt in z_txt.items():
        d[f"{z}_formed"] = f"EVENT (1 on the creation bar). {txt}"
        d[f"{z}_n_active"] = f"Active (not invalidated/expired) {z} zones after processing this bar."
        d[f"{z}_touched_now"] = f"1 if this bar touched at least one {z} zone that existed BEFORE this bar."
        d[f"{z}_invalidated_now"] = f"1 if this bar invalidated at least one {z} zone."
        d[f"{z}_in_zone"] = f"1 if close lies inside the nearest active {z} zone."
        d[f"{z}_top"] = f"Top price of the nearest active {z} zone (NaN if none)."
        d[f"{z}_bottom"] = f"Bottom price of the nearest active {z} zone."
        side = "above" if z.endswith("bull") else "below"
        d[f"{z}_dist_atr"] = f"Distance from close to the nearest active {z} zone edge facing price (zone is {'below' if side=='above' else 'above'} price), / ATR14; 0 if inside; NaN if no active zone."
        d[f"{z}_age"] = f"Bars since the nearest active {z} zone was created."
        d[f"{z}_touches"] = f"Number of bars that have touched the nearest active {z} zone since creation."
    return d
