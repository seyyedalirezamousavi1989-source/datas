"""Causal technical / price-action features.

Row convention: the row timestamp is the bar OPEN time. Every value in a row is a function
of that bar and earlier bars only, i.e. it is known at the bar close (open time + bar length).
Rolling windows never look forward; `shift(k)` is always k >= 0.
Definitions are registered next to the code that computes them, so the manifest is generated
from the executed logic rather than written by hand.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd

import config as C


def _wilder(s, n):
    return s.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()


def compute_technical(base, tf):
    """base: normalised frame (time, open, high, low, close, tick_volume, real_volume, spread, spread_known)."""
    P = C.TECH
    mins = C.TIMEFRAMES[tf][0]
    df = base.copy()
    defs = {}
    new = {}

    def add(name, values, text):
        new[name] = values
        defs[name] = text

    t = df["time"]
    o, h, l, c = df["open"], df["high"], df["low"], df["close"]
    tv = df["tick_volume"].astype("float64")

    # ---------------------------------------------------------------- time
    add("bar_close_time", (t + pd.Timedelta(minutes=mins)).dt.strftime("%Y-%m-%d %H:%M:%S"),
        "Nominal bar close time = open time + bar length of this file's timeframe (broker-server clock, unverified timezone). "
        "All features in the row are available at or after this instant.")
    add("server_hour", t.dt.hour.astype("int8"), "Hour (0-23) of the bar open time on the broker-server clock (timezone unverified).")
    add("server_minute", t.dt.minute.astype("int8"), "Minute of the bar open time on the broker-server clock.")
    add("minute_of_day", (t.dt.hour * 60 + t.dt.minute).astype("int16"), "server_hour*60 + server_minute.")
    add("dow", t.dt.dayofweek.astype("int8"), "Day of week of the bar open time, Monday=0 ... Friday=4 (no weekend bars exist).")
    ang = 2 * np.pi * (t.dt.hour * 60 + t.dt.minute) / 1440.0
    add("tod_sin", np.sin(ang), "sin(2*pi*minute_of_day/1440): cyclical time of day.")
    add("tod_cos", np.cos(ang), "cos(2*pi*minute_of_day/1440): cyclical time of day.")
    hr = t.dt.hour
    for name, (a, b) in C.SESSIONS.items():
        add(f"session_{name}", ((hr >= a) & (hr < b)).astype("int8"),
            f"ASSUMPTION-BASED flag: 1 if server_hour in [{a},{b}). Fixed server-clock window; the broker server timezone is "
            "unverified, so this is an approximation of the market session, not a verified session label.")

    # -------------------------------------------------------------- candle
    body = c - o
    rng = h - l
    safe_rng = rng.where(rng > 0)
    add("body", body, "close - open (price units).")
    add("body_abs", body.abs(), "|close - open|.")
    add("range", rng, "high - low.")
    add("upper_wick", h - np.maximum(o, c), "high - max(open, close).")
    add("lower_wick", np.minimum(o, c) - l, "min(open, close) - low.")
    add("direction", np.sign(body).astype("int8"), "+1 bullish (close>open), -1 bearish, 0 doji.")
    add("close_pos", (c - l) / safe_rng, "(close - low) / range; 0 = closed at low, 1 = at high; NaN if range==0.")
    add("body_ratio", body.abs() / safe_rng, "|body| / range; NaN if range==0.")
    add("upper_wick_ratio", (h - np.maximum(o, c)) / safe_rng, "upper_wick / range.")
    add("lower_wick_ratio", (np.minimum(o, c) - l) / safe_rng, "lower_wick / range.")
    prev_c = c.shift(1)
    add("gap_open", o - prev_c, "open - previous bar close (price units). Large values appear after session breaks / weekends.")

    # ------------------------------------------------------------- returns
    add("ret_1", c / prev_c - 1.0, "close/previous close - 1.")
    add("log_ret_1", np.log(c / prev_c), "ln(close/previous close).")
    for n in P["ret_windows"]:
        add(f"ret_{n}", c / c.shift(n) - 1.0, f"close / close {n} bars ago - 1 (momentum / rate of change).")

    # ------------------------------------------------------------ ATR / vol
    tr = pd.concat([h - l, (h - prev_c).abs(), (l - prev_c).abs()], axis=1).max(axis=1, skipna=False)
    tr.iloc[0] = np.nan  # no previous close for the first bar -> TR undefined (not fabricated)
    add("tr", tr, "True Range = max(high-low, |high-prev close|, |low-prev close|); NaN on the first bar.")
    a14 = _wilder(tr, P["atr_period"])
    a50 = _wilder(tr, P["atr_long_period"])
    add(f"atr_{P['atr_period']}", a14, f"Wilder ATR({P['atr_period']}): EWM alpha=1/{P['atr_period']}, seeded by first TR, NaN until {P['atr_period']} TR values exist.")
    add(f"atr_{P['atr_long_period']}", a50, f"Wilder ATR({P['atr_long_period']}).")
    add("atr_pct", a14 / c, "ATR14 / close.")
    add("atr_ratio", a14 / a50, "ATR14 / ATR50: short- vs long-term volatility regime (>1 expanding).")
    add("tr_atr_prev", tr / a14.shift(1), "TR / ATR14 of the previous bar (bar size relative to volatility known before the bar).")
    lr = np.log(c / prev_c)
    rvs = {}
    for n in P["rv_windows"]:
        rvs[n] = lr.rolling(n, min_periods=n).std(ddof=0)
        add(f"rv_{n}", rvs[n], f"Rolling population std of log_ret_1 over {n} bars (realised volatility).")
    n1, n2 = P["rv_windows"][0], P["rv_windows"][-1]
    add("rv_ratio", rvs[n1] / rvs[n2], f"rv_{n1} / rv_{n2}.")

    # ---------------------------------------------------------------- RSI
    d = c.diff()
    ag = _wilder(d.clip(lower=0), P["rsi_period"])
    al = _wilder((-d).clip(lower=0), P["rsi_period"])
    rs = ag / al
    rsi = 100 - 100 / (1 + rs)
    rsi = rsi.where(~((al == 0) & (ag > 0)), 100.0).where(~((al == 0) & (ag == 0)), 50.0)
    add(f"rsi_{P['rsi_period']}", rsi, f"Wilder RSI({P['rsi_period']}).")

    # ---------------------------------------------------------------- EMAs
    emas = {}
    for n in P["ema_periods"]:
        emas[n] = c.ewm(span=n, adjust=False, min_periods=n).mean()
        add(f"ema_{n}", emas[n], f"EMA({n}) of close, adjust=False, NaN until {n} bars exist (the first {n-1} rows are warm-up).")
        add(f"dist_ema_{n}_atr", (c - emas[n]) / a14, f"(close - EMA{n}) / ATR14 (signed, ATR units).")
    e1, e2, e3 = [emas[n] for n in P["ema_periods"]]
    p1, p2, p3 = P["ema_periods"]
    add(f"ema_{p1}_{p2}_diff_atr", (e1 - e2) / a14, f"(EMA{p1} - EMA{p2}) / ATR14.")
    add(f"ema_{p2}_{p3}_diff_atr", (e2 - e3) / a14, f"(EMA{p2} - EMA{p3}) / ATR14.")
    k = P["ema_slope_bars"]
    add(f"ema_{p1}_slope_atr", (e1 - e1.shift(k)) / a14, f"(EMA{p1} - EMA{p1} {k} bars ago) / ATR14.")
    add(f"ema_{p2}_slope_atr", (e2 - e2.shift(k)) / a14, f"(EMA{p2} - EMA{p2} {k} bars ago) / ATR14.")
    stack = pd.Series(0, index=df.index, dtype="int8")
    stack = stack.where(~((e1 > e2) & (e2 > e3)), 1).where(~((e1 < e2) & (e2 < e3)), -1)
    stack = stack.where(e3.notna(), 0).astype("int8")
    add("ema_stack", stack, f"+1 if EMA{p1}>EMA{p2}>EMA{p3}, -1 if EMA{p1}<EMA{p2}<EMA{p3}, else 0 (also 0 while EMA{p3} is warming up).")

    # ---------------------------------------------------------------- MACD
    f_, s_, g_ = P["macd"]
    macd = c.ewm(span=f_, adjust=False, min_periods=f_).mean() - c.ewm(span=s_, adjust=False, min_periods=s_).mean()
    sig = macd.ewm(span=g_, adjust=False, min_periods=g_).mean()
    add("macd", macd, f"EMA{f_}(close) - EMA{s_}(close).")
    add("macd_signal", sig, f"EMA{g_} of MACD.")
    add("macd_hist", macd - sig, "MACD - signal.")
    add("macd_hist_atr", (macd - sig) / a14, "MACD histogram / ATR14.")

    # ----------------------------------------------------------- Bollinger
    bn, bk = P["bb"]
    mid = c.rolling(bn, min_periods=bn).mean()
    sd = c.rolling(bn, min_periods=bn).std(ddof=0)
    up, lo = mid + bk * sd, mid - bk * sd
    add("bb_mid", mid, f"SMA({bn}) of close.")
    add("bb_upper", up, f"SMA({bn}) + {bk} * population std({bn}).")
    add("bb_lower", lo, f"SMA({bn}) - {bk} * population std({bn}).")
    add("bb_width", (up - lo) / mid, "(upper - lower) / mid.")
    add("bb_pctb", (c - lo) / (up - lo), "(close - lower) / (upper - lower).")

    # ------------------------------------- previous rolling highs / lows
    for n in P["roll_windows"]:
        ph = h.shift(1).rolling(n, min_periods=n).max()
        pl = l.shift(1).rolling(n, min_periods=n).min()
        add(f"prev_high_{n}", ph, f"Highest high of the {n} bars BEFORE the current bar (current bar excluded).")
        add(f"prev_low_{n}", pl, f"Lowest low of the {n} bars BEFORE the current bar (current bar excluded).")
        add(f"dist_prev_high_{n}_atr", (ph - c) / a14, f"(prev_high_{n} - close) / ATR14 (positive = price below that high).")
        add(f"dist_prev_low_{n}_atr", (c - pl) / a14, f"(close - prev_low_{n}) / ATR14 (positive = price above that low).")
        add(f"donchian_pos_{n}", (c - pl) / (ph - pl), f"(close - prev_low_{n}) / (prev_high_{n} - prev_low_{n}); outside [0,1] when price is beyond the range.")
    n0 = P["roll_windows"][0]
    add(f"brk_high_{n0}", (c > new[f"prev_high_{n0}"]).astype("int8"), f"1 if close > prev_high_{n0} (close-based breakout of the previous {n0}-bar high).")
    add(f"brk_low_{n0}", (c < new[f"prev_low_{n0}"]).astype("int8"), f"1 if close < prev_low_{n0}.")

    # ------------------------------------------------------- tick volume
    tw = P["tv_windows"]
    tsma = tv.rolling(tw["sma"], min_periods=tw["sma"]).mean()
    tmean = tv.rolling(tw["z"], min_periods=tw["z"]).mean()
    tstd = tv.rolling(tw["z"], min_periods=tw["z"]).std(ddof=0)
    add(f"tv_sma_{tw['sma']}", tsma, f"SMA({tw['sma']}) of tick_volume (tick count; NOT traded volume).")
    add(f"tv_rel_{tw['sma']}", tv / tsma, f"tick_volume / SMA({tw['sma']}) of tick_volume.")
    add(f"tv_z_{tw['z']}", (tv - tmean) / tstd.where(tstd > 0), f"z-score of tick_volume over {tw['z']} bars (population std).")
    add("tv_chg_1", tv / tv.shift(1) - 1.0, "tick_volume / previous tick_volume - 1.")
    add("tv_per_range", tv / rng.where(rng > 0), "tick_volume / bar range (ticks per price unit); NaN if range==0.")

    # ---------------------------------------------------------- momentum
    sgn = np.sign(c.diff()).fillna(0).astype("int8")
    run_id = (sgn != sgn.shift(1)).cumsum()
    run_len = sgn.groupby(run_id).cumcount() + 1
    add("streak", (run_len * sgn).astype("int16"), "Signed run length of consecutive closes in the same direction vs the prior close (+3 = 3 higher closes in a row).")

    # ----------------------------------------------- important levels
    date = t.dt.normalize()
    iso = t.dt.isocalendar()
    week = (iso["year"].astype("int64") * 100 + iso["week"].astype("int64"))
    gd = df.assign(_d=date).groupby("_d")
    gw = df.assign(_w=week).groupby("_w")
    dagg = gd.agg(h=("high", "max"), l=("low", "min"), c=("close", "last")).shift(1)
    wagg = gw.agg(h=("high", "max"), l=("low", "min"), c=("close", "last")).shift(1)
    pdh, pdl, pdc = date.map(dagg["h"]), date.map(dagg["l"]), date.map(dagg["c"])
    pwh, pwl = week.map(wagg["h"]), week.map(wagg["l"])
    dopen = gd["open"].transform("first")
    wopen = gw["open"].transform("first")
    dhi = gd["high"].cummax()
    dlo = gd["low"].cummin()
    add("prev_day_high", pdh.astype("float64"), "High of the previous trading DAY (server calendar date, fully closed before this bar).")
    add("prev_day_low", pdl.astype("float64"), "Low of the previous trading day.")
    add("prev_day_close", pdc.astype("float64"), "Close of the previous trading day.")
    add("prev_week_high", pwh.astype("float64"), "High of the previous ISO week (fully closed).")
    add("prev_week_low", pwl.astype("float64"), "Low of the previous ISO week.")
    add("day_open", dopen, "Open of the first bar of the current server-calendar day.")
    add("week_open", wopen, "Open of the first bar of the current ISO week.")
    add("day_high_so_far", dhi, "Highest high of the current day up to and including this bar.")
    add("day_low_so_far", dlo, "Lowest low of the current day up to and including this bar.")
    for nm, lv in [("prev_day_high", pdh), ("prev_day_low", pdl), ("prev_day_close", pdc), ("prev_week_high", pwh),
                   ("prev_week_low", pwl), ("day_open", dopen), ("week_open", wopen),
                   ("day_high_so_far", dhi), ("day_low_so_far", dlo)]:
        add(f"dist_{nm}_atr", (c - lv.astype("float64")) / a14, f"(close - {nm}) / ATR14 (signed).")
    for r in P["round_levels"]:
        nearest = np.round(c / r) * r
        add(f"dist_round_{r}_atr", (c - nearest) / a14, f"(close - nearest multiple of {r}) / ATR14 (psychological level distance, signed).")

    out = pd.concat([df, pd.DataFrame(new, index=df.index)], axis=1)
    out = out.replace([np.inf, -np.inf], np.nan)
    return out, defs
