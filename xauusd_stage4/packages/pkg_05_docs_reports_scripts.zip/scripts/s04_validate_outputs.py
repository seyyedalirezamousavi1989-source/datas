"""Stage 5 - independent validation of every generated file + causality (no-lookahead) tests.

Nothing here trusts the build code: swings, structure breaks, FVG, displacement and premium/discount
are re-derived with separate brute-force code and compared with the written files. Look-ahead is tested
by truncation: features recomputed from a prefix of the data must equal the full-run features on that prefix.
"""
import hashlib
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd

import config as C
import features_smc as FS
import features_tech as FT
from s02_build_features import build_frames, read_norm

R_ = C.DIR_REPORTS
results = {}
failures = []


def check(name, ok, detail=None):
    results[name] = {"pass": bool(ok), **({"detail": detail} if detail is not None else {})}
    if not ok:
        failures.append(name)
    print(("PASS " if ok else "FAIL ") + name, "" if detail is None else detail, flush=True)


# ------------------------------------------------------------------ inventory
def file_inventory():
    rows = []
    norm_rows = {}
    for tf in C.TF_ORDER:
        n_norm = None
        for stage, d, suffix in [("normalized", C.DIR_NORM, "normalized"), ("technical", C.DIR_TECH, "technical"),
                                 ("smc", C.DIR_SMC, "smc"), ("multitimeframe", C.DIR_MTF, "mtf")]:
            p = os.path.join(d, f"XAUUSD_{tf}_{suffix}.csv")
            if stage == "multitimeframe" and tf == "Daily":
                continue
            ok = os.path.exists(p)
            check(f"exists:{os.path.basename(p)}", ok)
            if not ok:
                continue
            df = pd.read_csv(p)
            n = len(df)
            if stage == "normalized":
                n_norm = n
                norm_rows[tf] = df["time"].values
            same_time = bool(np.array_equal(df["time"].values, norm_rows[tf]))
            num = df.select_dtypes("number")
            infs = int(np.isinf(num.to_numpy()).sum())
            mono = bool(pd.to_datetime(df["time"]).is_monotonic_increasing)
            check(f"rows_match_normalized+time_identical:{os.path.basename(p)}", n == n_norm and same_time, {"rows": n})
            check(f"no_inf+monotonic:{os.path.basename(p)}", infs == 0 and mono)
            all_nan = [c for c in df.columns if df[c].isna().all()]
            check(f"no_all_nan_columns:{os.path.basename(p)}", not all_nan, all_nan or None)
            rows.append({"stage": stage, "timeframe": tf, "file": os.path.relpath(p, C.ROOT), "rows": n,
                         "columns": df.shape[1], "bytes": os.path.getsize(p),
                         "nan_cells": int(df.isna().sum().sum()), "inf_cells": infs})
    inv = pd.DataFrame(rows)
    inv.to_csv(os.path.join(R_, "XAUUSD_output_file_inventory.csv"), index=False, lineterminator="\n")
    return inv


def column_profile():
    out = []
    for tf in C.TF_ORDER:
        p = os.path.join(C.DIR_SMC, f"XAUUSD_{tf}_smc.csv")
        df = pd.read_csv(p)
        for c in df.columns:
            s = df[c]
            fv = s.first_valid_index()
            rec = {"timeframe": tf, "column": c, "dtype": str(s.dtype), "nan_count": int(s.isna().sum()),
                   "nan_pct": round(float(s.isna().mean() * 100), 4), "first_valid_row": None if fv is None else int(fv)}
            if pd.api.types.is_numeric_dtype(s):
                rec.update(min=float(s.min()) if s.notna().any() else None, max=float(s.max()) if s.notna().any() else None)
            out.append(rec)
    prof = pd.DataFrame(out)
    prof.to_csv(os.path.join(R_, "XAUUSD_column_profile.csv"), index=False, lineterminator="\n")
    return prof


# ------------------------------------------------- independent re-derivations
def brute_swings(h, l, L, R):
    n = len(h)
    sh = np.zeros(n, bool)
    sl = np.zeros(n, bool)
    for i in range(L, n - R):
        if h[i] > h[i - L:i].max() and h[i] >= h[i + 1:i + R + 1].max():
            sh[i] = True
        if l[i] < l[i - L:i].min() and l[i] <= l[i + 1:i + R + 1].min():
            sl[i] = True
    return sh, sl


def brute_structure(c, sh_i, sl_i, h, l, R):
    """Independent BOS/CHOCH state machine from confirmed swings only."""
    n = len(c)
    ev = {k: np.zeros(n, np.int8) for k in ("bos_bull", "bos_bear", "choch_bull", "choch_bear")}
    trend_arr = np.zeros(n, np.int8)
    lsh = lsl = None
    sh_b = sl_b = True
    trend = 0
    for t in range(n):
        i = t - R
        if i >= 0 and sh_i[i]:
            lsh, sh_b = h[i], False
        if i >= 0 and sl_i[i]:
            lsl, sl_b = l[i], False
        if (not sh_b) and c[t] > lsh:
            ev["bos_bull" if trend >= 0 else "choch_bull"][t] = 1
            sh_b, trend = True, 1
        elif (not sl_b) and c[t] < lsl:
            ev["bos_bear" if trend <= 0 else "choch_bear"][t] = 1
            sl_b, trend = True, -1
        trend_arr[t] = trend
    return ev, trend_arr


def independent_smc_checks(tf):
    P = C.SMC
    L, R = P["swing_left"], P["swing_right"]
    df = pd.read_csv(os.path.join(C.DIR_SMC, f"XAUUSD_{tf}_smc.csv"))
    o, h, l, c = [df[k].to_numpy(float) for k in ("open", "high", "low", "close")]
    atr = df["atr_14"].to_numpy(float)
    n = len(df)
    sh, sl = brute_swings(h, l, L, R)
    ev_h = np.zeros(n, np.int8)
    ev_l = np.zeros(n, np.int8)
    ev_h[R:] = sh[:n - R]
    ev_l[R:] = sl[:n - R]
    check(f"smc[{tf}] swing_high_confirmed == brute force (confirmed only after {R} right candles)",
          np.array_equal(ev_h, df["swing_high_confirmed"].to_numpy()))
    check(f"smc[{tf}] swing_low_confirmed == brute force", np.array_equal(ev_l, df["swing_low_confirmed"].to_numpy()))
    first_sh = int(np.argmax(df["swing_high_confirmed"].to_numpy() == 1))
    check(f"smc[{tf}] last_swing_high is NaN until first confirmation", df["last_swing_high"].iloc[:first_sh].isna().all()
          and not np.isnan(df["last_swing_high"].iloc[first_sh]))
    ev, trend = brute_structure(c, sh, sl, h, l, R)
    for k, v in ev.items():
        check(f"smc[{tf}] {k} == independent state machine", np.array_equal(v, df[k].to_numpy()), {"events": int(v.sum())})
    check(f"smc[{tf}] trend_state == independent state machine", np.array_equal(trend, df["trend_state"].to_numpy()))
    # every break event: close beyond the reported level
    for k, sign in (("bos_bull", 1), ("choch_bull", 1), ("bos_bear", -1), ("choch_bear", -1)):
        idx = np.where(df[k].to_numpy() == 1)[0]
        lv = df["struct_break_level"].to_numpy()[idx]
        okc = np.all(c[idx] > lv) if sign == 1 else np.all(c[idx] < lv)
        check(f"smc[{tf}] {k}: close beyond struct_break_level on every event", okc)
    # FVG
    with np.errstate(invalid="ignore"):
        bull = (l[2:] > h[:-2]) & ((l[2:] - h[:-2]) >= P["fvg_min_atr"] * atr[2:])
        bear = (h[2:] < l[:-2]) & ((l[:-2] - h[2:]) >= P["fvg_min_atr"] * atr[2:])
    eb = np.zeros(n, np.int8); eb[2:] = bull
    es = np.zeros(n, np.int8); es[2:] = bear
    check(f"smc[{tf}] fvg_bull_formed == 3-candle rule", np.array_equal(eb, df["fvg_bull_formed"].to_numpy()), {"n": int(eb.sum())})
    check(f"smc[{tf}] fvg_bear_formed == 3-candle rule", np.array_equal(es, df["fvg_bear_formed"].to_numpy()), {"n": int(es.sum())})
    # active zones must never sit beyond price: bull zone bottom <= close, bear zone top >= close
    bb = df["fvg_bull_bottom"].to_numpy(); bt = df["fvg_bear_top"].to_numpy()
    check(f"smc[{tf}] no active bullish FVG with bottom above close / bearish with top below close",
          np.all(~(bb > c + 1e-6)) and np.all(~(bt < c - 1e-6)))
    for z, up in (("ob_bull", True), ("ob_bear", False)):
        b, tp = df[f"{z}_bottom"].to_numpy(), df[f"{z}_top"].to_numpy()
        okz = np.all(~(b > c + 1e-6)) if up else np.all(~(tp < c - 1e-6))
        check(f"smc[{tf}] active {z} zone never already invalidated by the close", okz)
    # OB only on structure breaks
    for z, evs in (("ob_bull", ("bos_bull", "choch_bull")), ("ob_bear", ("bos_bear", "choch_bear"))):
        f_ = df[f"{z}_formed"].to_numpy() == 1
        brk = (df[evs[0]].to_numpy() == 1) | (df[evs[1]].to_numpy() == 1)
        check(f"smc[{tf}] {z}_formed only on a BOS/CHOCH bar", np.all(brk[f_]), {"formed": int(f_.sum())})
    # displacement
    atr_prev = np.concatenate([[np.nan], atr[:-1]])
    rng = h - l
    with np.errstate(invalid="ignore", divide="ignore"):
        br = np.where(rng > 0, np.abs(c - o) / rng, 0)
        dd = np.where((rng / atr_prev >= P["disp_range_atr"]) & (br >= P["disp_body_ratio"]), np.sign(c - o), 0)
    check(f"smc[{tf}] disp_dir == definition (uses ATR of the PREVIOUS bar)", np.array_equal(dd.astype(np.int8), df["disp_dir"].to_numpy()))
    # premium / discount
    lsh, lsl = df["last_swing_high"].to_numpy(), df["last_swing_low"].to_numpy()
    valid = (~np.isnan(lsh)) & (~np.isnan(lsl)) & (lsh > lsl)
    with np.errstate(invalid="ignore", divide="ignore"):
        pos = np.where(valid, (c - lsl) / (lsh - lsl), np.nan)
    got = df["pd_pos"].to_numpy()
    check(f"smc[{tf}] pd_pos == (close-low)/(high-low) of last confirmed swings",
          np.allclose(pos, got, atol=2e-6, equal_nan=True) and np.array_equal(valid.astype(np.int8), df["pd_valid"].to_numpy()))
    # sweeps: necessary condition against an unexceeded confirmed swing pool
    sh_idx = np.where(sh)[0]
    bad = 0
    sw = np.where(df["bsl_sweep"].to_numpy() == 1)[0]
    for t in sw:
        cand = sh_idx[(sh_idx + R <= t) & (t - sh_idx <= P["liq_max_age"])]
        ok = False
        for i in cand[::-1]:
            lv = h[i]
            if h[t] > lv and c[t] <= lv and (t - 1 < i + 1 or h[i + 1:t].max() <= lv):
                ok = True
                break
        bad += (not ok)
    check(f"smc[{tf}] every bsl_sweep has a confirmed, unexceeded swing-high pool (wick above, close back)", bad == 0, {"sweeps": int(len(sw)), "violations": bad})
    sl_idx = np.where(sl)[0]
    bad = 0
    sw = np.where(df["ssl_sweep"].to_numpy() == 1)[0]
    for t in sw:
        cand = sl_idx[(sl_idx + R <= t) & (t - sl_idx <= P["liq_max_age"])]
        ok = False
        for i in cand[::-1]:
            lv = l[i]
            if l[t] < lv and c[t] >= lv and (t - 1 < i + 1 or l[i + 1:t].min() >= lv):
                ok = True
                break
        bad += (not ok)
    check(f"smc[{tf}] every ssl_sweep has a confirmed, unexceeded swing-low pool", bad == 0, {"sweeps": int(len(sw)), "violations": bad})


def handcrafted_smc_test():
    """L=R=1 zig-zag with a known answer: BOS-bear at t=7, CHOCH-bull at t=12."""
    h = [100, 104, 101, 99, 100, 102, 101, 98, 95, 97, 100, 99, 104]
    l = [98, 99, 96, 94, 95, 98, 96, 92, 91, 92, 95, 94, 96]
    c = [99, 103, 97, 95, 99, 101, 97, 93, 94, 96, 99, 95, 103]
    o = [99, 99, 103, 97, 95, 99, 101, 97, 93, 94, 96, 99, 95]
    df = pd.DataFrame({"open": o, "high": h, "low": l, "close": c, "atr_14": 1.0})
    P = dict(C.SMC, swing_left=1, swing_right=1, fvg_min_atr=0.0)
    out, _ = FS.compute_smc(df, "H1", P)
    ev = {k: np.where(out[k].to_numpy() == 1)[0].tolist() for k in ("bos_bull", "bos_bear", "choch_bull", "choch_bear")}
    ok = (ev["bos_bear"] == [7] and ev["choch_bull"] == [12] and ev["bos_bull"] == [] and ev["choch_bear"] == [])
    ok &= out["swing_high_confirmed"].to_numpy().tolist()[:3] == [0, 0, 1]      # swing at bar 1 confirmed at bar 2 (not before)
    ok &= bool(np.isnan(out["last_swing_high"].iloc[1])) and out["last_swing_high"].iloc[2] == 104
    ok &= out["struct_break_level"].iloc[7] == 94 and out["struct_break_level"].iloc[12] == 100
    ok &= out["trend_state"].iloc[12] == 1 and out["trend_state"].iloc[11] == -1
    check("smc[handcrafted] swing confirmation lag, BOS-bear then CHOCH-bull with known levels", bool(ok), ev)


# ----------------------------------------------------------- causality tests
def causality_truncation():
    cuts = {"Daily": [800, 1300], "H4": [4000], "H1": [15000, 28000], "M30": [30000], "M15": [60000], "M5": [120000]}
    summary = {}
    for tf in C.TF_ORDER:
        base = read_norm(tf)
        disk = pd.read_csv(os.path.join(C.DIR_SMC, f"XAUUSD_{tf}_smc.csv"))
        for cut in cuts[tf]:
            tech, smc, _, _ = build_frames(base.iloc[:cut].copy(), tf)
            full = pd.concat([tech, smc], axis=1)
            fl = full.select_dtypes("float").columns
            full[fl] = full[fl].round(C.ROUND_DEC)
            full["time"] = full["time"].dt.strftime("%Y-%m-%d %H:%M:%S")
            d = disk.iloc[:cut]
            assert list(full.columns) == list(d.columns)
            bad_cols = []
            for c in full.columns:
                a, b = full[c].reset_index(drop=True), d[c].reset_index(drop=True)
                if a.dtype == object or str(a.dtype).startswith("str"):
                    ok = bool((a == b).all())
                else:
                    ok = bool(np.allclose(a.to_numpy(float), b.to_numpy(float), rtol=0, atol=2e-6, equal_nan=True))
                if not ok:
                    bad_cols.append(c)
            check(f"no_lookahead[{tf}] features on first {cut} rows identical when later bars are removed", not bad_cols, bad_cols[:10] or None)
            summary[f"{tf}@{cut}"] = {"mismatching_columns": bad_cols}
    return summary


def mtf_checks():
    audits = []
    for ltf in C.TF_ORDER[:-1]:
        p = os.path.join(C.DIR_MTF, f"XAUUSD_{ltf}_mtf.csv")
        df = pd.read_csv(p)
        lm = C.TIMEFRAMES[ltf][0]
        ltf_close = pd.to_datetime(df["time"]) + pd.Timedelta(minutes=lm)
        base_cols = pd.read_csv(os.path.join(C.DIR_SMC, f"XAUUSD_{ltf}_smc.csv"), nrows=1).columns
        check(f"mtf[{ltf}] first columns identical to the SMC file", list(df.columns[:len(base_cols)]) == list(base_cols))
        for htf in C.TF_ORDER[C.TF_ORDER.index(ltf) + 1:]:
            pre, hm = C.TIMEFRAMES[htf][1], C.TIMEFRAMES[htf][0]
            bt = pd.to_datetime(df[f"{pre}_bar_time"])
            hclose = bt + pd.Timedelta(minutes=hm)
            nn = bt.notna()
            never_future = bool((hclose[nn] <= ltf_close[nn]).all())
            # brute-force independent lookup for a deterministic sample of rows
            h = pd.read_csv(os.path.join(C.DIR_SMC, f"XAUUSD_{htf}_smc.csv"), usecols=["time"] + C.MTF_COLUMNS, parse_dates=["time"])
            hc = (h["time"] + pd.Timedelta(minutes=hm)).to_numpy("datetime64[ns]")
            rng = np.random.default_rng(7)
            sample = rng.choice(len(df), size=min(3000, len(df)), replace=False)
            wrong = 0
            for s in sample:
                pos = np.searchsorted(hc, ltf_close.iloc[s].to_datetime64(), side="right") - 1
                exp_time = None if pos < 0 else str(h["time"].iloc[pos])
                got = df[f"{pre}_bar_time"].iloc[s]
                got = None if pd.isna(got) else got
                if exp_time != got:
                    wrong += 1
                    continue
                if pos >= 0:
                    for cname in ("close", "atr_14", "trend_state"):
                        e, g = h[cname].iloc[pos], df[f"{pre}_{cname}"].iloc[s]
                        if not (pd.isna(e) and pd.isna(g)) and abs(float(e) - float(g)) > 2e-6:
                            wrong += 1
                            break
            # an HTF candle is never the one still forming: no row may reference the HTF bar that contains the LTF bar
            containing_open = (pd.to_datetime(df["time"]).dt.floor("1D") if htf == "Daily"
                               else pd.to_datetime(df["time"]).dt.floor(f"{hm}min"))
            same_bar_leak = int(((bt == containing_open) & (hclose > ltf_close)).sum())
            check(f"mtf[{ltf}<-{htf}] HTF candle fully closed at LTF close; {len(sample)} sampled rows match brute-force lookup; no forming-candle reference",
                  never_future and wrong == 0 and same_bar_leak == 0,
                  {"htf_close_after_ltf_close": int((hclose[nn] > ltf_close[nn]).sum()), "sample_mismatches": wrong, "forming_candle_refs": same_bar_leak,
                   "rows_without_htf_yet": int((~nn).sum())})
            audits.append({"ltf": ltf, "htf": htf, "rows_without_htf_yet": int((~nn).sum()),
                           "max_age_min": float(df[f"{pre}_age_min"].max()), "median_age_min": float(df[f"{pre}_age_min"].median())})
    return audits


def indicator_cross_check():
    """Plain-python Wilder ATR/RSI, EMA, MACD, Bollinger on the first 1500 H1 rows vs written file."""
    df = pd.read_csv(os.path.join(C.DIR_TECH, "XAUUSD_H1_technical.csv"), nrows=1500)
    h, l, c = df["high"].tolist(), df["low"].tolist(), df["close"].tolist()
    n = len(c)
    tr = [None] + [max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])) for i in range(1, n)]
    atr = [None] * n
    a = None
    cnt = 0
    for i in range(1, n):
        a = tr[i] if a is None else a + (tr[i] - a) / 14.0
        cnt += 1
        atr[i] = a if cnt >= 14 else None
    g = l_ = None
    rsi = [None] * n
    for i in range(1, n):
        d = c[i] - c[i - 1]
        gain, loss = max(d, 0.0), max(-d, 0.0)
        g = gain if g is None else g + (gain - g) / 14.0
        l_ = loss if l_ is None else l_ + (loss - l_) / 14.0
        if i >= 14:
            rsi[i] = 100.0 if l_ == 0 and g > 0 else (50.0 if l_ == 0 else 100 - 100 / (1 + g / l_))
    k = 2 / 21.0
    e = c[0]
    ema20 = [None] * n
    for i in range(n):
        e = c[i] if i == 0 else e + k * (c[i] - e)
        ema20[i] = e if i >= 19 else None
    bb_u = [None] * n
    for i in range(19, n):
        w = c[i - 19:i + 1]
        m = sum(w) / 20
        sd = (sum((x - m) ** 2 for x in w) / 20) ** 0.5
        bb_u[i] = m + 2 * sd
    def cmp(name, mine):
        got = df[name].to_numpy(float)
        exp = np.array([np.nan if v is None else v for v in mine], float)
        return bool(np.allclose(got, exp, atol=2e-6, rtol=0, equal_nan=True))
    check("indicators[H1] atr_14 == independent Wilder implementation", cmp("atr_14", atr))
    check("indicators[H1] rsi_14 == independent Wilder implementation", cmp("rsi_14", rsi))
    check("indicators[H1] ema_20 == independent implementation", cmp("ema_20", ema20))
    check("indicators[H1] bb_upper == independent implementation", cmp("bb_upper", bb_u))


def source_unchanged():
    sha = hashlib.sha256(open(C.SOURCE_ZIP, "rb").read()).hexdigest()
    rep = json.load(open(os.path.join(R_, "XAUUSD_data_quality_report.json")))
    check("source ZIP sha256 equals the value recorded by stage 1", sha == rep["source_archive"]["sha256"], sha)


def main():
    source_unchanged()
    inv = file_inventory()
    prof = column_profile()
    handcrafted_smc_test()
    indicator_cross_check()
    for tf in ("Daily", "H4", "H1", "M30", "M15", "M5"):
        independent_smc_checks(tf)
    caus = causality_truncation()
    mtf = mtf_checks()
    # warm-up guidance measured from the technical files
    warm = {}
    for tf in C.TF_ORDER:
        t = pd.read_csv(os.path.join(C.DIR_TECH, f"XAUUSD_{tf}_technical.csv"))
        core = [c for c in t.columns if c.startswith(("ema_200", "atr_50", "rsi_14", "macd_signal", "bb_upper", "prev_high_100", "rv_50", "tv_z_50"))]
        full_valid = t[core].notna().all(axis=1)
        warm[tf] = {"first_row_with_all_core_indicators_valid": int(full_valid.idxmax()), "core_columns_checked": core}
    rep = {"overall_pass": not failures, "checks_total": len(results), "checks_failed": failures,
           "checks": results, "warmup_rows": warm, "mtf_audit": mtf, "causality": caus}
    with open(os.path.join(R_, "XAUUSD_output_validation_report.json"), "w") as f:
        json.dump(rep, f, indent=1, default=str)
    pd.DataFrame([{"check": k, "pass": v["pass"], "detail": json.dumps(v.get("detail"), default=str)} for k, v in results.items()]).to_csv(
        os.path.join(R_, "XAUUSD_output_validation_checks.csv"), index=False, lineterminator="\n")
    print(f"\nOVERALL: {'PASS' if not failures else 'FAIL'}  ({len(results)} checks, {len(failures)} failed)")
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
