"""Stage 2/3 - technical features (02_technical) and SMC-enriched datasets (03_smc), per timeframe.

usage: python3 s02_build_features.py [TF ...]      (default: all timeframes)
"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd

import config as C
import features_smc as FS
import features_tech as FT


def read_norm(tf):
    df = pd.read_csv(os.path.join(C.DIR_NORM, f"XAUUSD_{tf}_normalized.csv"), parse_dates=["time"])
    return df


def write_csv(df, path):
    w = df.copy()
    w["time"] = w["time"].dt.strftime("%Y-%m-%d %H:%M:%S")
    fl = w.select_dtypes("float").columns
    w[fl] = w[fl].round(C.ROUND_DEC)
    w.to_csv(path, index=False, lineterminator="\n")


def build_frames(base, tf):
    """Pure function used by the build AND by the causality tests."""
    tech, tdefs = FT.compute_technical(base, tf)
    smc, sdefs = FS.compute_smc(tech, tf)
    return tech, smc, tdefs, sdefs


def main(tfs):
    for d in (C.DIR_TECH, C.DIR_SMC, C.DIR_REPORTS):
        os.makedirs(d, exist_ok=True)
    for tf in tfs:
        t0 = time.time()
        base = read_norm(tf)
        tech, smc, tdefs, sdefs = build_frames(base, tf)
        full = pd.concat([tech, smc], axis=1)
        write_csv(tech, os.path.join(C.DIR_TECH, f"XAUUSD_{tf}_technical.csv"))
        write_csv(full, os.path.join(C.DIR_SMC, f"XAUUSD_{tf}_smc.csv"))
        with open(os.path.join(C.DIR_REPORTS, f"feature_definitions_{tf}.json"), "w") as f:
            json.dump({"technical": tdefs, "smc": sdefs}, f, indent=1)
        print(f"[{tf}] rows={len(full)} technical_cols={tech.shape[1]} smc_cols={full.shape[1]} {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main(sys.argv[1:] or C.TF_ORDER)
