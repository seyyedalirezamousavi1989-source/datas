"""Stage 7 - package deliverables into manageable ZIP files.

usage: python3 s06_package.py data    # dataset CSV packages (pkg_01..pkg_04)
       python3 s06_package.py docs    # manifest + README + reports + scripts + untouched source archive (pkg_05)
"""
import os
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as C

PK = os.path.join(C.OUT, "packages")


def add(zf, path, arc):
    zf.write(path, arc, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)


def make(name, items):
    os.makedirs(PK, exist_ok=True)
    p = os.path.join(PK, name)
    if os.path.exists(p):
        os.remove(p)
    with zipfile.ZipFile(p, "w") as zf:
        for path, arc in items:
            add(zf, path, arc)
    print(f"{name}: {os.path.getsize(p)/1e6:.1f} MB ({len(items)} files)", flush=True)


def data():
    def f(d, folder, suf, tfs):
        return [(os.path.join(d, f"XAUUSD_{tf}_{suf}.csv"), f"{folder}/XAUUSD_{tf}_{suf}.csv") for tf in tfs]
    make("pkg_01_normalized_all.zip", f(C.DIR_NORM, "01_normalized", "normalized", C.TF_ORDER))
    groups = [("M5", ["M5"]), ("M15_M30", ["M15", "M30"]), ("H1_H4_Daily", ["H1", "H4", "Daily"])]
    for n, (d, folder, suf) in enumerate([(C.DIR_TECH, "02_technical", "technical"), (C.DIR_SMC, "03_smc", "smc"),
                                           (C.DIR_MTF, "04_multitimeframe", "mtf")], start=2):
        for gname, tfs in groups:
            tfs = [t for t in tfs if not (suf == "mtf" and t == "Daily")]
            make(f"pkg_0{n}_{suf}_{gname}.zip", f(d, folder, suf, tfs))


def docs():
    items = [(os.path.join(C.OUT, "XAUUSD_Stage4_SMC_Manifest.json"), "XAUUSD_Stage4_SMC_Manifest.json"),
             (os.path.join(C.OUT, "XAUUSD_Stage5_Labeling_Proposal.md"), "XAUUSD_Stage5_Labeling_Proposal.md"),
             (os.path.join(C.ROOT, "README.md"), "README.md"),
             (C.SOURCE_ZIP, "source/XAUUSD.zip")]
    for n in sorted(os.listdir(C.DIR_REPORTS)):
        items.append((os.path.join(C.DIR_REPORTS, n), f"05_reports/{n}"))
    for n in sorted(os.listdir(os.path.dirname(os.path.abspath(__file__)))):
        if n.endswith((".py", ".sh", ".txt")):
            items.append((os.path.join(os.path.dirname(os.path.abspath(__file__)), n), f"scripts/{n}"))
    make("pkg_05_docs_reports_scripts.zip", items)


if __name__ == "__main__":
    {"data": data, "docs": docs}[sys.argv[1]]()
