"""Central configuration for the XAUUSD dataset pipeline (v1.0.0).

Every tunable parameter lives here and is echoed into the manifest, so the
documented rules and the executed rules cannot drift apart.
"""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOURCE_ZIP = os.path.join(ROOT, "source", "XAUUSD.zip")
OUT = os.path.join(ROOT, "out")
DIR_NORM = os.path.join(OUT, "01_normalized")
DIR_TECH = os.path.join(OUT, "02_technical")
DIR_SMC = os.path.join(OUT, "03_smc")
DIR_MTF = os.path.join(OUT, "04_multitimeframe")
DIR_REPORTS = os.path.join(OUT, "05_reports")

DATASET_VERSION = "1.0.0"
INSTRUMENT, ASSET, BROKER = "XAUUSD", "Gold", "Alpari"

# label -> (minutes, column prefix used when this TF is joined into a lower TF)
TIMEFRAMES = {
    "M5": (5, "m5"),
    "M15": (15, "m15"),
    "M30": (30, "m30"),
    "H1": (60, "h1"),
    "H4": (240, "h4"),
    "Daily": (1440, "d1"),
}
TF_ORDER = ["M5", "M15", "M30", "H1", "H4", "Daily"]  # ascending bar length

# ---------------------------------------------------------------- technical
TECH = dict(
    atr_period=14, atr_long_period=50, rsi_period=14,
    ema_periods=[20, 50, 200], macd=(12, 26, 9), bb=(20, 2.0),
    roll_windows=[20, 50, 100], ret_windows=[3, 5, 10, 20],
    rv_windows=[20, 50], tv_windows=dict(sma=20, z=50),
    ema_slope_bars=5, round_levels=[50, 100],
)

# --------------------------------------------------------------------- SMC
SMC = dict(
    swing_left=5, swing_right=5,          # swing high/low fractal window (bars)
    eq_tol_atr=0.10,                      # equal highs/lows tolerance (x ATR14 at confirmation)
    liq_cap=20, liq_max_age=500,          # active liquidity pools kept per side / max age (bars)
    fvg_min_atr=0.10,                     # min FVG size (x ATR14 at creation)
    zone_max_age=300, fvg_cap=15, ob_cap=10,
    ob_lookback=15,                       # bars scanned back for the OB candle
    disp_range_atr=1.5, disp_body_ratio=0.60,  # displacement candle
    pd_eq_band=0.05,                      # equilibrium band half-width around 0.5
)

# Higher-timeframe columns joined into lower-timeframe rows.
MTF_COLUMNS = [
    "close", "direction", "atr_14", "rsi_14", "dist_ema_50_atr", "ema_stack",
    "macd_hist_atr", "trend_state", "struct_last_event", "pd_pos",
    "last_swing_high", "last_swing_low", "fvg_bull_dist_atr", "fvg_bear_dist_atr",
    "ob_bull_dist_atr", "ob_bear_dist_atr",
]

# Session windows in *server clock hours* (assumption-based, see README).
SESSIONS = dict(asia=(1, 10), london=(10, 19), ny=(15, 24), london_ny_overlap=(15, 19))

ROUND_DEC = 6   # decimals kept when writing float feature columns
