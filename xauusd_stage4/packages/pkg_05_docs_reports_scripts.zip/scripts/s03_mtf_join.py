"""Stage 4 - multi-timeframe alignment (04_multitimeframe).

Rule (no unfinished higher-timeframe candle is ever exposed):
  ltf_close = ltf_open_time + ltf_minutes          (instant at which the lower-TF row is known)
  htf_close = htf_open_time + htf_minutes          (NOMINAL close of the higher-TF candle)
  Each lower-TF row receives the LATEST higher-TF row with htf_close <= ltf_close
  (pandas.merge_asof, direction='backward', allow_exact_matches=True).
All HTF values are the features computed at the HTF candle's own close, so they are already causal.
Using the nominal close is conservative: on shortened sessions the real last tick is earlier than the
nominal close, which can only delay (never advance) the availability of an HTF candle.
"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd

import config as C
from s02_build_features import write_csv


def load_smc(tf, usecols=None):
    p = os.path.join(C.DIR_SMC, f"XAUUSD_{tf}_smc.csv")
    return pd.read_csv(p, parse_dates=["time"], usecols=usecols)


def join_one(ltf_df, ltf, htf):
    lm, hm = C.TIMEFRAMES[ltf][0], C.TIMEFRAMES[htf][0]
    pre = C.TIMEFRAMES[htf][1]
    h = load_smc(htf, usecols=["time"] + C.MTF_COLUMNS)
    h["_htf_close"] = (h["time"] + pd.Timedelta(minutes=hm)).astype("datetime64[ns]")
    h = h.rename(columns={"time": f"{pre}_bar_time"})
    h = h.rename(columns={c: f"{pre}_{c}" for c in C.MTF_COLUMNS})
    h = h.sort_values("_htf_close")
    left = pd.DataFrame({"_ltf_close": (ltf_df["time"] + pd.Timedelta(minutes=lm)).astype("datetime64[ns]"),
                         "_i": range(len(ltf_df))}).sort_values("_ltf_close")
    m = pd.merge_asof(left, h, left_on="_ltf_close", right_on="_htf_close", direction="backward", allow_exact_matches=True)
    m = m.sort_values("_i").reset_index(drop=True)
    age = (m["_ltf_close"] - m["_htf_close"]).dt.total_seconds() / 60.0
    # audit: the HTF candle must be fully closed at the LTF close
    ok = (m["_htf_close"].isna() | (m["_htf_close"] <= m["_ltf_close"])).all()
    audit = {"ltf": ltf, "htf": htf, "rows": int(len(m)),
             "rows_without_closed_htf_candle_yet": int(m["_htf_close"].isna().sum()),
             "htf_close_never_after_ltf_close": bool(ok),
             "min_htf_age_minutes": float(age.min()), "median_htf_age_minutes": float(age.median()),
             "max_htf_age_minutes": float(age.max())}
    m[f"{pre}_age_min"] = age
    m[f"{pre}_bar_time"] = m[f"{pre}_bar_time"].dt.strftime("%Y-%m-%d %H:%M:%S")
    keep = [f"{pre}_bar_time", f"{pre}_age_min"] + [f"{pre}_{c}" for c in C.MTF_COLUMNS]
    return m[keep], audit


def main(ltfs):
    os.makedirs(C.DIR_MTF, exist_ok=True)
    audits = []
    for ltf in ltfs:
        t0 = time.time()
        df = load_smc(ltf)
        i = C.TF_ORDER.index(ltf)
        parts = [df]
        for htf in C.TF_ORDER[i + 1:]:
            j, a = join_one(df, ltf, htf)
            assert a["htf_close_never_after_ltf_close"], (ltf, htf)
            parts.append(j)
            audits.append(a)
        out = pd.concat(parts, axis=1)
        write_csv(out, os.path.join(C.DIR_MTF, f"XAUUSD_{ltf}_mtf.csv"))
        print(f"[{ltf}] rows={len(out)} cols={out.shape[1]} {time.time()-t0:.0f}s", flush=True)
        with open(os.path.join(C.DIR_REPORTS, f"mtf_join_audit_{ltf}.json"), "w") as f:
            json.dump([a for a in audits if a["ltf"] == ltf], f, indent=1)


if __name__ == "__main__":
    main(sys.argv[1:] or C.TF_ORDER[:-1])
