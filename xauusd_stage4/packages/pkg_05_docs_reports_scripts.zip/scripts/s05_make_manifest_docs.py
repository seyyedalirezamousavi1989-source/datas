"""Stage 6 - build XAUUSD_Stage4_SMC_Manifest.json, README.md and the labeling proposal.

Every number below is READ from the generated files / reports (never typed in by hand).
usage: python3 s05_make_manifest_docs.py   (run after s04_validate_outputs.py and s06_package.py data)
"""
import datetime as dt
import hashlib
import json
import os
import platform
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd

import config as C

R = C.DIR_REPORTS
STAGES = [("normalized", C.DIR_NORM, "normalized", "01_normalized"), ("technical", C.DIR_TECH, "technical", "02_technical"),
          ("smc", C.DIR_SMC, "smc", "03_smc"), ("multitimeframe", C.DIR_MTF, "mtf", "04_multitimeframe")]


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for ch in iter(lambda: f.read(1 << 22), b""):
            h.update(ch)
    return h.hexdigest()


def jload(name):
    with open(os.path.join(R, name)) as f:
        return json.load(f)


def gather():
    q = jload("XAUUSD_data_quality_report.json")
    v = jload("XAUUSD_output_validation_report.json")
    prof = pd.read_csv(os.path.join(R, "XAUUSD_column_profile.csv"))
    inv = pd.read_csv(os.path.join(R, "XAUUSD_output_file_inventory.csv"))
    defs = {tf: jload(f"feature_definitions_{tf}.json") for tf in C.TF_ORDER}
    return q, v, prof, inv, defs


def event_counts():
    cols = ["swing_high_confirmed", "swing_low_confirmed", "bos_bull", "bos_bear", "choch_bull", "choch_bear", "bsl_sweep", "ssl_sweep",
            "eqh_formed", "eql_formed", "fvg_bull_formed", "fvg_bear_formed", "ob_bull_formed", "ob_bear_formed"]
    out = {}
    for tf in C.TF_ORDER:
        d = pd.read_csv(os.path.join(C.DIR_SMC, f"XAUUSD_{tf}_smc.csv"), usecols=cols + ["disp_dir", "pd_valid"])
        r = {c: int(d[c].sum()) for c in cols}
        r["displacement_candles"] = int((d["disp_dir"] != 0).sum())
        r["rows_with_valid_premium_discount_range"] = int(d["pd_valid"].sum())
        r["rows"] = int(len(d))
        out[tf] = r
    return out


def build_catalog(prof, defs, q):
    base_defs = {
        "time": "Bar OPEN time exactly as exported by MT5 (naive broker-server clock, timezone UNVERIFIED). Text 'YYYY-MM-DD HH:MM:SS'.",
        "open": "Bar open price (source value, unchanged).", "high": "Bar high.", "low": "Bar low.", "close": "Bar close.",
        "tick_volume": "MT5 tick count in the bar (source <TICKVOL>). A proxy for activity; NOT traded volume.",
        "real_volume": "Source <VOL>. 0 in every row of every file: not provided by the feed. Not real volume; not used by any feature.",
        "spread": "Source <SPREAD> in MT5 points. 0 means UNKNOWN/unverified, not a free trade.",
        "spread_known": "1 if spread > 0 else 0 (marks rows whose spread value can be used).",
    }
    cat = {}
    p_smc = prof
    for _, r in p_smc.iterrows():
        e = cat.setdefault(r["column"], {"dtype_by_timeframe": {}})
        e["dtype_by_timeframe"][r["timeframe"]] = r["dtype"]
    for c, e in cat.items():
        vals = set(e["dtype_by_timeframe"].values())
        e["dtype"] = sorted(vals)[0] if len(vals) == 1 else "mixed (see dtype_by_timeframe)"
        if len(vals) == 1:
            del e["dtype_by_timeframe"]
        d = base_defs.get(c) or defs["H1"]["technical"].get(c) or defs["H1"]["smc"].get(c)
        e["definition"] = d
        e["group"] = ("source" if c in base_defs else "technical" if c in defs["H1"]["technical"] else "smc")
    # multi-timeframe columns
    mtf = {}
    for htf in C.TF_ORDER[1:]:
        pre = C.TIMEFRAMES[htf][1]
        mtf[f"{pre}_bar_time"] = {"dtype": "str (datetime text)", "group": "multitimeframe",
                                  "definition": f"Open time of the {htf} candle that was the latest FULLY CLOSED {htf} candle at the lower-TF row's close. Empty until the first {htf} candle has closed."}
        mtf[f"{pre}_age_min"] = {"dtype": "float64", "group": "multitimeframe",
                                 "definition": f"Minutes between that {htf} candle's nominal close and the lower-TF row's close (0 = it closed at the same instant; large after weekends/breaks)."}
        for c in C.MTF_COLUMNS:
            src = cat[c]
            mtf[f"{pre}_{c}"] = {"dtype": src["dtype"] if "dtype" in src else "float64", "group": "multitimeframe",
                                 "definition": f"'{c}' of the latest fully closed {htf} candle. Original definition: {src['definition']}"}
    cat.update(mtf)
    undocumented = [c for c, e in cat.items() if not e.get("definition")]
    assert not undocumented, undocumented
    return cat


def file_entries(inv):
    out = []
    for stage, d, suf, folder in STAGES:
        for tf in C.TF_ORDER:
            if stage == "multitimeframe" and tf == "Daily":
                continue
            p = os.path.join(d, f"XAUUSD_{tf}_{suf}.csv")
            cols = list(pd.read_csv(p, nrows=0).columns)
            row = inv[(inv.stage == stage) & (inv.timeframe == tf)].iloc[0]
            out.append({"stage": stage, "timeframe": tf, "file": f"{folder}/XAUUSD_{tf}_{suf}.csv", "rows": int(row["rows"]),
                        "column_count": len(cols), "bytes": int(row["bytes"]), "sha256": sha256(p), "columns": cols})
    return out


def package_entries():
    d = os.path.join(C.OUT, "packages")
    if not os.path.isdir(d):
        return []
    return [{"zip": n, "bytes": os.path.getsize(os.path.join(d, n)), "sha256": sha256(os.path.join(d, n))} for n in sorted(os.listdir(d)) if n.endswith(".zip")]


def stats_for_labeling():
    rows = []
    for tf in C.TF_ORDER:
        d = pd.read_csv(os.path.join(C.DIR_TECH, f"XAUUSD_{tf}_technical.csv"), usecols=["time", "atr_14", "close", "spread", "spread_known", "range"], parse_dates=["time"])
        d["year"] = d["time"].dt.year
        g = d.groupby("year")
        for y, x in g:
            kn = x[x["spread_known"] == 1]
            rows.append({"timeframe": tf, "year": int(y), "bars": int(len(x)), "median_atr14_usd": float(x["atr_14"].median()),
                         "median_bar_range_usd": float(x["range"].median()),
                         "median_known_spread_points": float(kn["spread"].median()) if len(kn) else np.nan,
                         "spread_zero_share": float((x["spread"] == 0).mean())})
    s = pd.DataFrame(rows)
    s.to_csv(os.path.join(R, "XAUUSD_atr_spread_by_year_and_timeframe.csv"), index=False, lineterminator="\n")
    return s


def main():
    q, v, prof, inv, defs = gather()
    ev = event_counts()
    cat = build_catalog(prof, defs, q)
    files = file_entries(inv)
    pk = package_entries()
    st = stats_for_labeling()
    diag = q["timestamp_status"]["diagnostics"]
    now = dt.datetime.now(dt.timezone.utc)
    warm = v["warmup_rows"]
    manifest = {
        "manifest_name": "XAUUSD_Stage4_SMC_Manifest",
        "dataset_version": C.DATASET_VERSION,
        "generated_utc": now.strftime("%Y-%m-%d %H:%M:%S"),
        "generation_date": now.strftime("%Y-%m-%d"),
        "instrument": C.INSTRUMENT, "asset": C.ASSET, "broker": C.BROKER,
        "broker_note": "Broker name is taken from the task description; the source files themselves do not contain broker metadata.",
        "source": {"archive": "XAUUSD.zip", "sha256": q["source_archive"]["sha256"], "bytes": q["source_archive"]["bytes"],
                   "unchanged": True, "members": q["source_archive"]["members"],
                   "format": "MetaTrader 5 history export, tab-separated, CRLF, header <DATE> <TIME> <OPEN> <HIGH> <LOW> <CLOSE> <TICKVOL> <VOL> <SPREAD> (Daily has no <TIME>)",
                   "history_range": {"first": q["timeframes"]["M5"]["first_bar_time"][:10], "last": q["timeframes"]["M5"]["last_bar_time"][:10]}},
        "timeframes": {tf: {"minutes": C.TIMEFRAMES[tf][0], "column_prefix_when_joined_into_lower_timeframes": C.TIMEFRAMES[tf][1],
                            "rows": q["timeframes"][tf]["rows"], "first_bar_open": q["timeframes"][tf]["first_bar_time"],
                            "last_bar_open": q["timeframes"][tf]["last_bar_time"], "source_file": q["timeframes"][tf]["source_file"]} for tf in C.TF_ORDER},
        "output_files": files,
        "packages": pk,
        "packages_note": "pkg_05_docs_reports_scripts.zip contains this manifest, so its own size/hash cannot be listed here.",
        "column_catalog": cat,
        "technical_feature_parameters": C.TECH,
        "smc_parameters": C.SMC,
        "session_windows_server_hours_ASSUMPTION": C.SESSIONS,
        "technical_feature_definitions": defs["H1"]["technical"],
        "smc_feature_definitions": defs["H1"]["smc"],
        "smc_event_counts_measured": ev,
        "causality_rules": {
            "row_timestamp": "bar OPEN time; every value in the row is a function of bars <= this bar only (known at open time + bar length).",
            "indicators": "rolling/EWM windows only look backwards; previous highs/lows/levels exclude the current bar; ATR-based thresholds for displacement use ATR of the previous bar.",
            "swings": f"a swing at bar i is published at bar i+{C.SMC['swing_right']} (all confirmation candles closed); structure breaks use closes beyond confirmed levels only.",
            "zones": "FVG/OB are created at the close of the bar that completes them and can only be touched/invalidated by LATER bars.",
            "tests": "truncation test (features on a prefix equal the full-run values) + independent brute-force re-derivations; see validation report.",
        },
        "multitimeframe_alignment": {
            "method": "pandas.merge_asof(direction='backward', allow_exact_matches=True) on nominal close times",
            "lower_tf_known_at": "ltf_open_time + ltf_minutes",
            "higher_tf_available_when": "htf_open_time + htf_minutes <= ltf_open_time + ltf_minutes",
            "unfinished_candles": "never exposed; an HTF candle appears only on the first lower-TF row whose close is >= the HTF candle's nominal close",
            "joined_columns_per_htf": C.MTF_COLUMNS, "extra_columns_per_htf": ["<prefix>_bar_time", "<prefix>_age_min"],
            "files": [f"XAUUSD_{tf}_mtf.csv" for tf in C.TF_ORDER[:-1]],
            "audit": v["mtf_audit"],
            "conservative_note": "Nominal close is used even on shortened sessions; this can only delay, never advance, HTF availability.",
        },
        "timestamp_and_timezone": {
            "timestamps_modified": False,
            "convention": "MT5 bar open time on the broker-server clock",
            "timezone_status": "UNVERIFIED",
            "empirical_diagnostics": diag,
            "consequence": "Session flags and hour-of-day features are expressed in server-clock hours only; no UTC conversion was made.",
        },
        "data_quality_summary": {tf: {k: q["timeframes"][tf][k] for k in ("rows", "timestamps_off_timeframe_grid", "zero_range_candles_high_eq_low",
                                                                           "real_volume", "spread_points", "gaps")} |
                                 {"cleaning": q["timeframes"][tf]["cleaning"]} for tf in C.TF_ORDER},
        "cross_timeframe_consistency_vs_M5": q["cross_timeframe_consistency_vs_M5"],
        "validation": {"overall_pass": v["overall_pass"], "checks_total": v["checks_total"], "checks_failed": v["checks_failed"],
                       "report": "05_reports/XAUUSD_output_validation_report.json"},
        "warmup_rows_measured": {tf: warm[tf]["first_row_with_all_core_indicators_valid"] for tf in C.TF_ORDER},
        "warmup_guidance": "Rows before the index above have at least one core indicator (EMA200 etc.) undefined. SMC state (structure, zones, liquidity) also needs burn-in; "
                           "a conservative practice is to discard at least the first 500 rows of every timeframe before building labels.",
        "verified_facts": [
            "All six timeframes were read; no duplicate timestamps, no OHLC violations, no missing values, all timestamps on the timeframe grid (see data_quality_summary).",
            "M15/M30/H1/H4/Daily bars equal the aggregation of the M5 bars (open/high/low/close/tick_volume) for every covered bar (cross_timeframe_consistency_vs_M5).",
            "No candle is missing inside trading sessions; the only gaps are daily breaks, weekends and 17 multi-day holiday gaps (gaps summary).",
            "real_volume == 0 in every row of every file.",
            "Features pass the truncation (no look-ahead) tests and independent re-derivations listed in the validation report.",
        ],
        "assumptions": [
            "Prices are assumed to be broker BID candles (the MT5 default); the files do not state it.",
            "MT5 spread is in points; a point is assumed to be 0.01 USD only because prices carry 2 decimals. Not verified and NOT used in any feature.",
            "Server timezone is NOT assumed in any computation; session windows are fixed server-hour ranges meant as rough proxies.",
            "SMC parameters (swing 5/5, FVG min 0.10 ATR, displacement 1.5 ATR / body 0.6, equal-level tolerance 0.10 ATR, ...) are a-priori choices, not optimised.",
        ],
        "unresolved_issues": [
            "Exact historical broker-server timezone and DST rules (empirical pattern is consistent with EET/EEST but unverified).",
            "Meaning of the MT5 spread field per bar (open/last/max) and the point size.",
            "Commission and slippage for the intended trading account are unknown.",
            "No external price source was available, so absolute price accuracy cannot be cross-checked (only internal consistency).",
            "No economic-calendar/news data is included; none was invented.",
        ],
        "known_limitations": [
            "Raw price-level columns (open/high/low/close, EMAs, Bollinger bands, previous highs/lows, levels, SMC zone prices) are non-stationary (gold traded from ~1,615 to ~5,598 USD in the file). Prefer the ATR-normalised/relative columns for modelling.",
            "Order Blocks are a heuristic interpretation; zones are capped in number and expire after a fixed number of bars, so very old zones are forgotten by design.",
            "Swings need 5 closed bars on each side, so structure information lags price by 5 bars.",
            "Tick volume is broker-specific and not comparable with exchange volume.",
            "Spread==0 rows are unknown; zero-spread share is not uniform across years (see reports).",
            "Only one broker feed; no tick data; no order-book data.",
            "Daily candles and day/week levels use the server calendar date, which in US/EU DST-mismatch weeks is shifted by one hour relative to the New York-based market break.",
            "The data starts on 2020-11-11, so there is no pre-history for indicator warm-up.",
        ],
        "training_readiness": {
            "feature_dataset": "VALIDATED" if v["overall_pass"] else "FAILED VALIDATION",
            "labels": "NOT GENERATED (by design for this stage)",
            "model_training_started": False,
            "ready_for_model_training": False,
            "blocking_items": ["Labeling methodology not yet approved/implemented (see XAUUSD_Stage5_Labeling_Proposal.md)",
                               "Transaction-cost assumptions (spread/commission/slippage) not finalised",
                               "Timezone unresolved (affects session features only)"],
            "usable_now_for": ["feature exploration", "implementing and testing the labeling stage", "SMC rule review"],
        },
        "environment": {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__, "platform": platform.platform()},
    }
    with open(os.path.join(C.OUT, "XAUUSD_Stage4_SMC_Manifest.json"), "w") as f:
        json.dump(manifest, f, indent=1, default=str)
    write_readme(manifest, ev, files, pk, st, q, v)
    write_labeling(manifest, st, q)
    print("manifest, README and labeling proposal written")


def fmt_bytes(n):
    return f"{n/1e6:,.1f} MB"


def write_readme(m, ev, files, pk, st, q, v):
    P, S = C.TECH, C.SMC
    tf_tab = "\n".join(f"| {tf} | {m['timeframes'][tf]['rows']:,} | {m['timeframes'][tf]['first_bar_open']} | {m['timeframes'][tf]['last_bar_open']} |" for tf in C.TF_ORDER)
    file_tab = "\n".join(f"| `{f['file']}` | {f['rows']:,} | {f['column_count']} | {fmt_bytes(f['bytes'])} |" for f in files)
    pk_tab = "\n".join(f"| `{p['zip']}` | {fmt_bytes(p['bytes'])} |" for p in pk) or "| (see packages folder) | |"
    ev_cols = ["swing_high_confirmed", "swing_low_confirmed", "bos_bull", "bos_bear", "choch_bull", "choch_bear", "bsl_sweep", "ssl_sweep", "eqh_formed", "eql_formed",
               "fvg_bull_formed", "fvg_bear_formed", "ob_bull_formed", "ob_bear_formed", "displacement_candles"]
    ev_tab = "| event | " + " | ".join(C.TF_ORDER) + " |\n|---|" + "---|" * len(C.TF_ORDER) + "\n" + "\n".join(
        f"| {c} | " + " | ".join(f"{ev[tf][c]:,}" for tf in C.TF_ORDER) + " |" for c in ev_cols)
    dq = "\n".join(f"| {tf} | {q['timeframes'][tf]['cleaning']['duplicate_timestamps_found']} | {q['timeframes'][tf]['cleaning']['rows_dropped_invalid_candles']} | "
                   f"{q['timeframes'][tf]['timestamps_off_timeframe_grid']} | {q['timeframes'][tf]['spread_points']['zero_rows']:,} ({q['timeframes'][tf]['spread_points']['zero_share']*100:.2f}%) | "
                   f"{q['timeframes'][tf]['gaps']['by_category'].get('weekend', 0)} / {q['timeframes'][tf]['gaps']['by_category'].get('overnight_break', 0)} / {q['timeframes'][tf]['gaps']['by_category'].get('multi_day_gap', 0)} |"
                   for tf in C.TF_ORDER)
    diag = m["timestamp_and_timezone"]["empirical_diagnostics"]
    txt = f"""# XAUUSD (Gold) AI Training Dataset - Stage 4 (technical + SMC + multi-timeframe features)

**Dataset version:** {m['dataset_version']}  |  **Generated (UTC):** {m['generated_utc']}  |  **Instrument:** XAUUSD (Gold), broker feed: Alpari (per task description), MetaTrader 5 candles

## 1. Status in one paragraph
The feature dataset was built from the raw MT5 candles only and validated with {v['checks_total']} automated checks
({'all passed' if v['overall_pass'] else 'SOME FAILED - see report'}). **No training labels (LONG/SHORT/NO TRADE) exist yet and no model was trained**; this is deliberate.
A separate labeling proposal is in `XAUUSD_Stage5_Labeling_Proposal.md`. The dataset is *not yet ready for model training* until the labeling stage and the open issues in section 12 are resolved.

## 2. Layout
```
source/XAUUSD.zip                  original archive, byte-identical copy (sha256 {m['source']['sha256']})
scripts/                           reproducible pipeline (config.py, s01..s06, features_tech.py, features_smc.py, run_all.sh)
out/01_normalized/                 cleaned raw candles, 6 timeframes
out/02_technical/                  raw + time + technical/price-action features, 6 timeframes
out/03_smc/                        technical + SMC features (self-contained superset of 02), 6 timeframes
out/04_multitimeframe/             SMC dataset + closed higher-timeframe context, 5 lower timeframes (Daily is the top)
out/05_reports/                    data-quality, validation, gap, profile reports (JSON + CSV)
out/XAUUSD_Stage4_SMC_Manifest.json   machine-readable description of everything (columns, dtypes, definitions, results, limitations)
```
Each file is a plain CSV (comma separated, header row, `\\n` line endings, floats rounded to {C.ROUND_DEC} decimals, empty cell = undefined/NaN).
Rows of all stage files of one timeframe are identical in number and order (1:1 on `time`).

## 3. Source data (measured)
| timeframe | rows | first bar (open) | last bar (open) |
|---|---|---|---|
{tf_tab}

* Tab-separated MT5 export, columns `<DATE> <TIME> <OPEN> <HIGH> <LOW> <CLOSE> <TICKVOL> <VOL> <SPREAD>` (Daily has no `<TIME>`). Prices have 2 decimals.
* Timestamps are bar **open** times (confirmed: M15/M30/H1/H4/Daily bars equal the aggregation of M5 bars labelled by open time, 100% of covered bars).
* Weekends have no bars; there is a daily break; no candle is missing inside sessions (MT5 creates no bar without ticks).

## 4. Cleaning and validation (stage 1)
Normalised columns: `time, open, high, low, close, tick_volume, real_volume, spread, spread_known`. Original values were never altered; rows would only be dropped for exact duplicate timestamps or invalid OHLC (none occurred).

| TF | duplicates | invalid dropped | off-grid timestamps | spread==0 rows | gaps: weekend / overnight / multi-day |
|---|---|---|---|---|---|
{dq}

* `real_volume` is 0 in every row: documented, **not** interpreted as traded volume, not used.
* `spread == 0` is treated as **unknown**, not as zero cost (`spread_known` flag). Spread is in MT5 points; point size is not stated in the files.
* Timeframe consistency (M5 aggregated vs. exported higher timeframes) matched on every covered bar: see `05_reports/XAUUSD_timeframe_consistency.csv`.

## 5. Timestamp / timezone status: UNVERIFIED
All timestamps are exactly as exported (naive broker-server clock). Empirical pattern: on {diag['in_window_last_bar_22h']} of {diag['dates_in_us_eu_dst_mismatch_window']} trading dates inside the weeks where US and EU daylight-saving differ, the last H1 bar of the day opens at 22:00 instead of 23:00,
and this never happens outside those weeks ({diag['out_window_last_bar_22h']} of {diag['dates_outside_window']}). That is consistent with a server clock following EU DST (EET/EEST) but it is **an inference, not a verification**.
Therefore no UTC conversion was done and session features are fixed server-hour windows (assumption-based): asia {C.SESSIONS['asia']}, london {C.SESSIONS['london']}, ny {C.SESSIONS['ny']}, overlap {C.SESSIONS['london_ny_overlap']}.
A measured server-hour volatility profile is in `05_reports/XAUUSD_H1_hourly_profile_server_time.csv`.

## 6. Technical and price-action features (110 columns incl. source columns in `02_technical`)
Candle body/range/wicks/direction/close position and ratios, gap to previous close, returns and log returns (1,3,5,10,20), True Range, Wilder ATR 14/50, ATR% and ATR ratio, realised volatility 20/50,
Wilder RSI 14, EMA 20/50/200 with ATR-normalised distances, spreads and slopes plus an EMA stack flag, MACD 12/26/9 (+ATR-normalised histogram), Bollinger 20/2 (population std),
previous 20/50/100-bar highs/lows (current bar excluded) with ATR distances, Donchian position and 20-bar breakout flags, tick-volume statistics (SMA, relative, z-score, change, ticks per range),
signed close streak, previous day/week levels, day/week open, running day high/low, distance to round numbers (50/100 USD), and time-of-day features.
**Every column has an exact definition in the manifest (`column_catalog`) - generated from the same code that computes it.**
Indicators with `min_periods` are NaN while warming up (first 199 rows for EMA200).

## 7. SMC rules (all parameters in `scripts/config.py`; echoed in the manifest)
| concept | rule (summary) |
|---|---|
| Swing high/low | bar i is a swing high if high[i] > max(high[i-{S['swing_left']}..i-1]) and high[i] >= max(high[i+1..i+{S['swing_right']}]); mirror for lows. Published only at bar i+{S['swing_right']}. |
| BOS | close beyond the last confirmed, not-yet-broken swing level in the direction of the current state (state 0 -> first break is a BOS). Each level breaks once. |
| CHOCH | close beyond the last confirmed swing level **against** the current state (bullish CHOCH when state is bearish and vice versa). |
| Liquidity sweep | wick beyond an active confirmed swing pool (<= {S['liq_max_age']} bars old, not yet exceeded) with the close back on the original side; the pool is consumed on first excursion. If the close is beyond the level it is a break, not a sweep. |
| Equal highs / lows | a new confirmed swing within {S['eq_tol_atr']} x ATR14 of an active unswept swing of the same side. |
| FVG | 3-candle gap (low[t] > high[t-2] bullish; high[t] < low[t-2] bearish), size >= {S['fvg_min_atr']} x ATR14. Touch = later bar overlaps the zone; invalidated = later **close** beyond the far edge; expires after {S['zone_max_age']} bars; max {S['fvg_cap']} zones per side. |
| Order Block (heuristic) | at a BOS/CHOCH close: last opposite-colour candle within {S['ob_lookback']} bars, only if a same-direction displacement candle lies in the leg; zone = that candle's range. Touch/invalidation/expiry as FVG; max {S['ob_cap']} per side. |
| Premium / discount | position of close inside [last confirmed swing low, last confirmed swing high]; premium > {0.5+S['pd_eq_band']:.2f}, discount < {0.5-S['pd_eq_band']:.2f}, equilibrium band between; undefined if the range is invalid. |
| Displacement | range >= {S['disp_range_atr']} x ATR14 of the previous bar and body/range >= {S['disp_body_ratio']}. |

Order Blocks are heuristic interpretations, not objectively verified facts; a frequent pattern is **not** assumed to be profitable.
Measured event counts (from the files):

{ev_tab}

## 8. Gold-specific considerations
Gold shows sudden range expansion, regime changes in volatility, strong reactions at round numbers and prior day/week extremes, frequent sweeps/false breaks and news-driven spikes.
The dataset therefore (a) normalises distances by ATR instead of fixed price/pip units (no Forex pip assumptions were reused), (b) provides volatility-regime features (ATR ratio, realised-vol ratio, displacement strength),
(c) provides psychological-level (50/100 USD) distances, (d) provides sweep/equal-level features and (e) keeps server-hour features so session dependence can be learned or examined.
**No news or economic-calendar data is included and none was invented.**

## 9. Multi-timeframe alignment
Lower-timeframe rows are known at `open + bar length`. A higher-timeframe candle is attached to a lower-timeframe row only if its nominal close (`open + its length`) is <= that instant
(`merge_asof`, backward, exact matches allowed because both candles are complete at that instant). Unfinished H1/H4/Daily candles are never exposed. Columns added per higher timeframe
(prefix `m15_ m30_ h1_ h4_ d1_`): `bar_time`, `age_min` and {len(C.MTF_COLUMNS)} context columns ({', '.join(C.MTF_COLUMNS)}). Rows before the first closed higher-timeframe candle have empty values.
Independent brute-force lookups on 3,000 sampled rows per (lower, higher) pair and a full-file inequality check passed.

## 10. Files
| file | rows | columns | size |
|---|---|---|---|
{file_tab}

ZIP packages (`packages/`):

| package | size |
|---|---|
{pk_tab}

## 11. Reproduce
```
python3 scripts/s01_clean_validate.py          # reads source/XAUUSD.zip read-only
python3 scripts/s02_build_features.py          # technical + SMC (all timeframes, or pass names e.g. H1 M15)
python3 scripts/s03_mtf_join.py                # multi-timeframe join
python3 scripts/s04_validate_outputs.py        # 100% of the checks quoted here
```
Needs only Python 3, pandas and numpy (tested with pandas {pd.__version__}, numpy {np.__version__}); no network, no compiled extras. The SMC pass is a plain Python loop (about 2 minutes for M5).

## 12. Known limitations / open issues
""" + "\n".join(f"* {x}" for x in m["known_limitations"] + m["unresolved_issues"]) + f"""

## 13. How to use the features safely
* Row `time` is the **open** time; features are final at `bar_close_time`. Build labels from the *next* bar onward.
* Drop at least the first 500 rows of every timeframe (warm-up of EMA200 and the SMC state).
* Do not feed raw price levels directly to a model; use the ATR-normalised and relative columns.
* Treat `spread == 0` as unknown and never as free execution.
* Split chronologically with purging/embargo (see the labeling proposal).

## 14. Not done (by design)
No LONG/SHORT/NO TRADE labels, no backtest, no performance claim, no model training.
"""
    with open(os.path.join(C.ROOT, "README.md"), "w") as f:
        f.write(txt)


def write_labeling(m, st, q):
    ref = st[st.timeframe.isin(["M15", "H1", "H4", "Daily"])].copy()
    tab = "| TF | year | median ATR14 (USD) | median known spread (points) | spread==0 share |\n|---|---|---|---|---|\n" + "\n".join(
        f"| {r.timeframe} | {r.year} | {r.median_atr14_usd:.2f} | {r.median_known_spread_points:.0f} | {r.spread_zero_share*100:.1f}% |" for r in ref.itertuples())
    first, last = q["timeframes"]["M5"]["first_bar_time"][:10], q["timeframes"]["M5"]["last_bar_time"][:10]
    txt = f"""# XAUUSD Stage 5 - Labeling Methodology PROPOSAL (not implemented)

Status: **proposal only.** No labels were created, no label statistics, no backtest, no profitability claim. Everything marked *parameter* is a starting point to be reviewed and fixed **before** any label is generated,
and tuned (if at all) on the validation period only.

## 1. Principles
1. A label for bar *t* may use only information up to the close of *t* for the decision, and prices from *t+1* onward for the outcome.
2. The outcome is simulated with explicit barriers and **explicit costs**; zero cost is never assumed.
3. Ambiguity is flagged, not hidden.
4. Train/validation/test are chronological, with purging and embargo.
5. The test period is touched once, at the very end.

## 2. Decision and entry
* Decision at the close of bar *t* (features in the `*_smc` / `*_mtf` rows).
* Market entry at the **open of bar t+1**. Long fills at ask = open + spread, short fills at bid = open (assuming the candles are BID candles - unverified, see manifest).
* Gap handling: if the entry open is already beyond a barrier (weekend / break gap), the trade exits at that open price plus slippage; this is a realistic loss, not an error.

## 3. Barriers (triple-barrier style, per direction)
* Stop distance `SL = k_sl x ATR14[t]` (ATR frozen at the decision bar, never re-read later). *Parameter:* k_sl in {{1.0, 1.5, 2.0}}, headline 1.5.
  Rationale: displacement candles in this dataset are defined as >= 1.5 x ATR of the previous bar, so a stop tighter than ~1 ATR is inside ordinary Gold noise.
* Floor: `SL >= m x (spread + slippage)` with *parameter* m = 5, so cost never dominates the trade.
* Target `TP = RR x SL`; *parameter* RR in {{1.0, 1.5, 2.0}}.
* Vertical barrier (max holding) `H` bars. *Parameter (starting point):* M5 48 (4 h), M15 32 (8 h), M30 24 (12 h), H1 24 (1 day), H4 12 (2 days), Daily 10 (2 weeks).
* Horizons that cross a weekend or a multi-day holiday gap: primary rule = **exclude the sample** (label undefined), alternative = keep and flag `crosses_gap`.

## 4. Costs (all explicit, all scenario-based)
* **Spread:** use the bar's spread only when `spread_known == 1`; otherwise fall back to the median known spread of the previous 500 bars of the same timeframe and set `spread_imputed = 1`.
  Spread is in MT5 points; converting to USD needs the point size (assumed 0.01 USD, **unverified** - confirm with the broker contract specification).
  Measured known-spread medians change a lot by year (table below), so a single constant spread would be wrong.
* **Commission:** not in the data and account-dependent. Define scenarios (none / low / base / high) and report results for each; fix the headline value only after the real account terms are known.
* **Slippage:** model as a fraction of ATR14 (scenarios, e.g. 0.00 / 0.02 / 0.05 x ATR) and widen it for bars flagged as displacement or high `atr_ratio`.
* Costs are charged on entry and exit; net R = (gross outcome - costs) / SL.

Measured volatility and spread context (from the generated technical files):

{tab}

(full table: `05_reports/XAUUSD_atr_spread_by_year_and_timeframe.csv`)

## 5. Label definition
For each bar and each direction the path is simulated until a barrier is hit:
* TP first -> win (net R > 0 after costs);  SL first -> loss;  neither by H -> timeout with mark-to-market net R.
* `LONG` if the long outcome is a net win and the short outcome is not;  `SHORT` symmetrically;  `NO_TRADE` otherwise (both lose, timeout, two-sided whipsaw, ambiguous, or net R below a minimum edge threshold `theta` - *parameter*, default 0).
* Keep auxiliary columns: net R long/short, bars to exit, exit reason, `ambiguous`, `spread_imputed`, `crosses_gap`.

## 6. Ambiguous candles
When one candle touches both SL and TP:
1. replay the same interval on the lower timeframe (M5 for M15 and above; the M5 bar is the finest available);
2. if still ambiguous (both inside one M5 bar) assume the **worst case (SL first)** and set `ambiguous = 1`;
3. report how many samples are ambiguous per timeframe and test the model with and without them.

## 7. Chronological splits, purging, embargo
Data spans {first} to {last}. Proposed split (by calendar, identical dates for all timeframes):
* Train: {first} - 2024-06-30;  Validation: 2024-07-01 - 2025-06-30;  Test: 2025-07-01 - {last}.
* **Purge:** drop every training sample whose outcome window [t+1, t+H] reaches into the validation (or test) period.
* **Embargo:** additionally drop `E = max(H, ceil(0.01 x N_train))` bars after each boundary when a later segment is used for fitting (cross-validation folds).
* Gold changed regime (price roughly doubled+, strong trend phases): evaluate by sub-period and prefer walk-forward / rolling-origin validation over a single split.
* Normalisation statistics (if any) must be fitted on the training segment only.

## 8. Overlapping samples
Consecutive labels share most of their outcome window. Use average-uniqueness sample weights (or a stride of about H/2) and never shuffle across time.

## 9. Evaluation (when a model exists)
Report net R expectancy per trade, hit rate against the break-even rate implied by RR and costs, number of trades, drawdown of the simulated R stream, and results per year, per session window and per volatility regime.
Always compare with the trivial baselines (always NO_TRADE, random direction, simple trend rule) under the same cost model. Accuracy alone is not a valid objective.

## 10. Decisions needed from you before implementation
1. Primary decision timeframe(s) (e.g. M15 or H1) and which higher timeframes are context only.
2. Broker contract specification: point size, commission, typical slippage, whether candles are bid.
3. Horizon set and RR/SL grid above, and the weekend/holiday-gap rule.
4. Whether ambiguous samples should be dropped or kept with worst-case labels.
5. Final split dates.

## 11. Deliverables of the labeling stage (planned)
`XAUUSD_<TF>_labels.csv` keyed by `time` (+ auxiliary columns), `XAUUSD_Stage5_Labels_Manifest.json`, a validation report (label counts, ambiguity share, leakage checks, purge/embargo audit) and the reproducible script.
"""
    with open(os.path.join(C.OUT, "XAUUSD_Stage5_Labeling_Proposal.md"), "w") as f:
        f.write(txt)


if __name__ == "__main__":
    main()
