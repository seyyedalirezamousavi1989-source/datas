"""Stage 1 - read raw MT5 CSVs straight from the source ZIP, normalise, validate, report.

* The source ZIP is opened read-only; nothing is extracted or modified.
* Original MT5 timestamps are kept exactly as exported (naive broker-server time).
* No candle or price is ever invented. Rows are only dropped if they are exact
  timestamp duplicates or violate OHLC relationships (count is reported; currently
  the report shows what was actually found).
"""
import hashlib
import json
import os
import re
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd

import config as C

RAW_COLS_INTRADAY = ["<DATE>", "<TIME>", "<OPEN>", "<HIGH>", "<LOW>", "<CLOSE>", "<TICKVOL>", "<VOL>", "<SPREAD>"]
RAW_COLS_DAILY = [c for c in RAW_COLS_INTRADAY if c != "<TIME>"]
RENAME = {"<OPEN>": "open", "<HIGH>": "high", "<LOW>": "low", "<CLOSE>": "close",
          "<TICKVOL>": "tick_volume", "<VOL>": "real_volume", "<SPREAD>": "spread"}
NORM_COLUMNS = ["time", "open", "high", "low", "close", "tick_volume", "real_volume", "spread", "spread_known"]
NORM_DTYPES = {"time": "datetime64[ns] (written as 'YYYY-MM-DD HH:MM:SS', naive broker-server time, bar OPEN time)",
               "open": "float64", "high": "float64", "low": "float64", "close": "float64",
               "tick_volume": "int64", "real_volume": "int64", "spread": "int64 (MT5 points)",
               "spread_known": "int8 (1 if spread>0 else 0; spread==0 is treated as UNKNOWN)"}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def tf_of(filename):
    m = re.match(r"XAUUSD_(M5|M15|M30|H1|H4|Daily)_(\d{12})_(\d{12})\.csv$", os.path.basename(filename))
    if not m:
        raise ValueError(f"unrecognised source file name: {filename}")
    return m.group(1), m.group(2), m.group(3)


def load_raw(zf, name, tf):
    """Return (raw string frame, header list). Reads every field as text first."""
    with zf.open(name) as fh:
        raw = pd.read_csv(fh, sep="\t", dtype=str, keep_default_na=False)
    expected = RAW_COLS_DAILY if tf == "Daily" else RAW_COLS_INTRADAY
    if list(raw.columns) != expected:
        raise ValueError(f"{name}: unexpected header {list(raw.columns)}")
    return raw


def normalise(raw, tf):
    """Raw text frame -> typed normalised frame + dict of cleaning counters."""
    info = {"raw_rows": int(len(raw))}
    if tf == "Daily":
        ts = pd.to_datetime(raw["<DATE>"], format="%Y.%m.%d", errors="coerce")
    else:
        ts = pd.to_datetime(raw["<DATE>"] + " " + raw["<TIME>"], format="%Y.%m.%d %H:%M:%S", errors="coerce")
    df = pd.DataFrame({"time": ts})
    for src, dst in RENAME.items():
        df[dst] = pd.to_numeric(raw[src], errors="coerce")
    info["unparseable_timestamps"] = int(df["time"].isna().sum())
    info["nan_cells_after_parse"] = {c: int(df[c].isna().sum()) for c in df.columns}
    bad_na = df.isna().any(axis=1)
    info["rows_dropped_missing_values"] = int(bad_na.sum())
    df = df[~bad_na]

    if not df["time"].is_monotonic_increasing:
        info["was_unsorted"] = True
        df = df.sort_values("time", kind="stable")
    else:
        info["was_unsorted"] = False

    dup = df["time"].duplicated(keep="first")
    info["duplicate_timestamps_found"] = int(dup.sum())
    df = df[~dup]

    o, h, l, c = df["open"], df["high"], df["low"], df["close"]
    nonpos = (o <= 0) | (h <= 0) | (l <= 0) | (c <= 0)
    rel = (h < np.maximum(o, c)) | (l > np.minimum(o, c)) | (h < l)
    invalid = nonpos | rel
    info["non_positive_price_rows"] = int(nonpos.sum())
    info["ohlc_relationship_violations"] = int(rel.sum())
    info["rows_dropped_invalid_candles"] = int(invalid.sum())
    invalid_rows = df[invalid].copy()
    df = df[~invalid]

    info["negative_tick_volume_rows"] = int((df["tick_volume"] < 0).sum())
    info["negative_spread_rows"] = int((df["spread"] < 0).sum())
    df = df.reset_index(drop=True)
    for col in ("tick_volume", "real_volume", "spread"):
        df[col] = df[col].astype("int64")
    df["spread_known"] = (df["spread"] > 0).astype("int8")
    info["clean_rows"] = int(len(df))
    return df[NORM_COLUMNS], info, invalid_rows


# ------------------------------------------------------------------ checks
def grid_violations(df, tf):
    t = df["time"]
    mins = C.TIMEFRAMES[tf][0]
    if tf == "Daily":
        bad = (t.dt.hour != 0) | (t.dt.minute != 0) | (t.dt.second != 0)
    elif tf == "H4":
        bad = (t.dt.hour % 4 != 0) | (t.dt.minute != 0) | (t.dt.second != 0)
    elif tf == "H1":
        bad = (t.dt.minute != 0) | (t.dt.second != 0)
    else:
        bad = (t.dt.minute % mins != 0) | (t.dt.second != 0)
    return int(bad.sum())


def gap_analysis(df, tf):
    """Classify every spacing larger than one bar. Missing bars are NOT filled."""
    mins = C.TIMEFRAMES[tf][0]
    t = df["time"]
    diff_min = t.diff().dt.total_seconds().div(60)
    prev_t = t.shift(1)
    idx = np.where(diff_min > mins + 1e-9)[0]
    rows = []
    for i in idx:
        p, n = prev_t.iloc[i], t.iloc[i]
        gap = float(diff_min.iloc[i])
        day_delta = (n.normalize() - p.normalize()).days
        if p.dayofweek == 4 and n.dayofweek == 0 and day_delta <= 4 and (n - p) >= pd.Timedelta(hours=24):
            cat = "weekend"
        elif day_delta == 0:
            cat = "same_day_missing_bars"
        elif day_delta == 1:
            cat = "overnight_break"
        else:
            cat = "multi_day_gap"
        rows.append((tf, p, n, gap, cat, int(round(gap / mins)) - 1))
    g = pd.DataFrame(rows, columns=["timeframe", "prev_bar_time", "next_bar_time", "gap_minutes",
                                    "category", "missing_grid_slots"])
    return g


def timezone_diagnostics(h1):
    """Empirical session-boundary pattern per server date (no timestamp is modified)."""
    def nth_weekday(year, month, weekday, n):
        d = pd.Timestamp(year=year, month=month, day=1)
        d += pd.Timedelta(days=(weekday - d.dayofweek) % 7)
        return d + pd.Timedelta(weeks=n - 1)

    def last_weekday(year, month, weekday):
        d = pd.Timestamp(year=year, month=month, day=1) + pd.offsets.MonthEnd(0)
        return d - pd.Timedelta(days=(d.dayofweek - weekday) % 7)

    def us_dst(d):
        y = d.year
        return nth_weekday(y, 3, 6, 2) <= d < nth_weekday(y, 11, 6, 1)

    def eu_dst(d):
        y = d.year
        return last_weekday(y, 3, 6) <= d < last_weekday(y, 10, 6)

    g = h1.groupby(h1["time"].dt.normalize())["time"].agg(["min", "max"])
    first_h, last_h = g["min"].dt.hour, g["max"].dt.hour
    dates = g.index
    mismatch = np.array([us_dst(d) != eu_dst(d) for d in dates])
    # A "regular" full day ends with an H1 bar opened at 23:00 and starts at 01:00.
    early_end = (last_h.values == 22)
    start_00 = (first_h.values == 0)
    out = {
        "method": "per server calendar date, from H1 bars: hour of first/last bar vs. US/EU DST mismatch windows",
        "dates_in_us_eu_dst_mismatch_window": int(mismatch.sum()),
        "dates_outside_window": int((~mismatch).sum()),
        "in_window_last_bar_22h": int((early_end & mismatch).sum()),
        "in_window_first_bar_00h": int((start_00 & mismatch).sum()),
        "out_window_last_bar_22h": int((early_end & ~mismatch).sum()),
        "out_window_first_bar_00h": int((start_00 & ~mismatch).sum()),
        "last_bar_hour_distribution": {str(k): int(v) for k, v in last_h.value_counts().sort_index().items()},
        "first_bar_hour_distribution": {str(k): int(v) for k, v in first_h.value_counts().sort_index().items()},
    }
    n_in = max(out["dates_in_us_eu_dst_mismatch_window"], 1)
    n_out = max(out["dates_outside_window"], 1)
    in_share = out["in_window_last_bar_22h"] / n_in
    out_share = out["out_window_last_bar_22h"] / n_out
    out["share_in_window_session_ends_1h_early"] = round(in_share, 4)
    out["share_out_window_session_ends_1h_early"] = round(out_share, 4)
    if in_share >= 0.8 and out_share <= 0.15:
        out["interpretation"] = ("The daily session end shifts by one hour exactly in the weeks where US and EU "
                                 "daylight-saving differ. That is consistent with a broker server clock that follows "
                                 "EU DST (EET/EEST, UTC+2 winter / UTC+3 summer) while the underlying gold market "
                                 "break follows New York. This is an empirical inference only and is NOT an "
                                 "independent verification of the broker timezone.")
    else:
        out["interpretation"] = ("The measured pattern does not clearly match the US/EU DST mismatch windows; "
                                 "the server timezone remains unresolved.")
    out["status"] = "UNVERIFIED - timestamps kept exactly as exported"
    return out


def tf_consistency(frames):
    """Aggregate M5 up to every other TF and compare with the exported bars."""
    m5 = frames["M5"].set_index("time")
    results, mismatches = [], []
    for tf in ["M15", "M30", "H1", "H4", "Daily"]:
        mins = C.TIMEFRAMES[tf][0]
        key = m5.index.floor("1D") if tf == "Daily" else m5.index.floor(f"{mins}min")
        g = m5.groupby(key)
        agg = pd.DataFrame({"open": g["open"].first(), "high": g["high"].max(), "low": g["low"].min(),
                            "close": g["close"].last(), "tick_volume": g["tick_volume"].sum(),
                            "m5_bars": g["open"].size()})
        tgt = frames[tf].set_index("time")
        j = tgt.join(agg, rsuffix="_m5", how="left")
        has = j["m5_bars"].notna()
        full_n = mins // 5
        full = has & (j["m5_bars"] == full_n)
        row = {"timeframe": tf, "bars_in_file": int(len(j)), "bars_with_any_m5": int(has.sum()),
               "bars_without_m5_coverage": int((~has).sum()), "bars_with_full_m5_count": int(full.sum())}
        bad_any = pd.Series(False, index=j.index)
        for col in ["open", "high", "low", "close", "tick_volume"]:
            eq_all = (j[col] == j[col + "_m5"])
            row[f"{col}_match_rate_all_covered"] = round(float(eq_all[has].mean()), 6) if has.any() else None
            row[f"{col}_match_rate_full_bins"] = round(float(eq_all[full].mean()), 6) if full.any() else None
            bad_any |= has & ~eq_all
        row["covered_bars_with_any_mismatch"] = int(bad_any.sum())
        results.append(row)
        if bad_any.any():
            m = j[bad_any].head(200).reset_index()
            m.insert(0, "timeframe", tf)
            mismatches.append(m)
    mm = pd.concat(mismatches, ignore_index=True) if mismatches else pd.DataFrame()
    return results, mm


def main():
    for d in (C.DIR_NORM, C.DIR_REPORTS):
        os.makedirs(d, exist_ok=True)
    src_sha = sha256(C.SOURCE_ZIP)
    frames, tf_reports, all_gaps, summary_rows, rejected = {}, {}, [], [], []
    with zipfile.ZipFile(C.SOURCE_ZIP) as zf:
        members = {tf_of(n)[0]: n for n in zf.namelist() if n.lower().endswith(".csv")}
        assert set(members) == set(C.TF_ORDER), f"missing timeframes: {set(C.TF_ORDER) - set(members)}"
        zip_listing = [{"name": i.filename, "uncompressed_bytes": i.file_size} for i in zf.infolist()]
        for tf in C.TF_ORDER:
            name = members[tf]
            raw = load_raw(zf, name, tf)
            df, info, bad = normalise(raw, tf)
            frames[tf] = df
            if len(bad):
                b = bad.copy(); b.insert(0, "timeframe", tf); rejected.append(b)
            out_name = f"XAUUSD_{tf}_normalized.csv"
            out_path = os.path.join(C.DIR_NORM, out_name)
            w = df.copy()
            w["time"] = w["time"].dt.strftime("%Y-%m-%d %H:%M:%S")
            w.to_csv(out_path, index=False, lineterminator="\n")

            mins = C.TIMEFRAMES[tf][0]
            gaps = gap_analysis(df, tf)
            all_gaps.append(gaps)
            prices = df[["open", "high", "low", "close"]]
            dec = raw[["<OPEN>", "<HIGH>", "<LOW>", "<CLOSE>"]].apply(lambda s: s.str.split(".").str[1].str.len().fillna(0)).max().max()
            lr = np.log(df["close"]).diff()
            rng = df["high"] - df["low"]
            sp = df.loc[df["spread_known"] == 1, "spread"]
            cat_counts = gaps["category"].value_counts().to_dict()
            rep = {
                "source_file": name,
                "timeframe": tf, "bar_minutes": mins,
                "header_raw": list(raw.columns),
                "cleaning": info,
                "first_bar_time": str(df["time"].iloc[0]), "last_bar_time": str(df["time"].iloc[-1]),
                "rows": int(len(df)), "columns_normalized": len(NORM_COLUMNS),
                "timestamps_off_timeframe_grid": grid_violations(df, tf),
                "chronological_strictly_increasing": bool(df["time"].is_monotonic_increasing and not df["time"].duplicated().any()),
                "weekday_counts_mon0": {str(k): int(v) for k, v in df["time"].dt.dayofweek.value_counts().sort_index().items()},
                "price_decimal_places_max": int(dec),
                "price_min": float(prices.min().min()), "price_max": float(prices.max().max()),
                "zero_range_candles_high_eq_low": int((rng == 0).sum()),
                "tick_volume": {"min": int(df["tick_volume"].min()), "median": float(df["tick_volume"].median()),
                                "max": int(df["tick_volume"].max()), "zero_rows": int((df["tick_volume"] == 0).sum())},
                "real_volume": {"zero_rows": int((df["real_volume"] == 0).sum()), "total_rows": int(len(df)),
                                "all_zero": bool((df["real_volume"] == 0).all()),
                                "note": "real_volume is 0 in every row: not exported by the broker feed. It is NOT traded volume and is not used as a feature."},
                "spread_points": {"zero_rows": int((df["spread"] == 0).sum()),
                                  "zero_share": round(float((df["spread"] == 0).mean()), 6),
                                  "known_min": int(sp.min()) if len(sp) else None,
                                  "known_median": float(sp.median()) if len(sp) else None,
                                  "known_p95": float(sp.quantile(0.95)) if len(sp) else None,
                                  "known_max": int(sp.max()) if len(sp) else None,
                                  "note": "spread==0 is treated as UNKNOWN/unverified (not a zero transaction cost). MT5 spread is in points; point size is not stated in the files (prices carry 2 decimals)."},
                "max_abs_log_return_1bar": float(lr.abs().max()),
                "bars_abs_log_return_gt_1pct": int((lr.abs() > 0.01).sum()),
                "max_bar_range": float(rng.max()),
                "gaps": {"total_spacings_larger_than_one_bar": int(len(gaps)),
                         "by_category": {k: int(v) for k, v in cat_counts.items()},
                         "missing_grid_slots_same_day": int(gaps.loc[gaps.category == "same_day_missing_bars", "missing_grid_slots"].sum()),
                         "interpretation": "MT5 creates no bar for an interval without ticks. Missing slots are reported, never filled."},
                "output_file": os.path.relpath(out_path, C.ROOT),
            }
            tf_reports[tf] = rep
            flat = {"timeframe": tf, "rows": rep["rows"], "first_bar": rep["first_bar_time"], "last_bar": rep["last_bar_time"],
                    "duplicates_found": info["duplicate_timestamps_found"], "unsorted_in_source": info["was_unsorted"],
                    "invalid_candles_dropped": info["rows_dropped_invalid_candles"],
                    "rows_dropped_missing_values": info["rows_dropped_missing_values"],
                    "off_grid_timestamps": rep["timestamps_off_timeframe_grid"],
                    "zero_range_candles": rep["zero_range_candles_high_eq_low"],
                    "real_volume_zero_rows": rep["real_volume"]["zero_rows"],
                    "spread_zero_rows": rep["spread_points"]["zero_rows"],
                    "spread_zero_share": rep["spread_points"]["zero_share"],
                    "same_day_missing_slots": rep["gaps"]["missing_grid_slots_same_day"],
                    "multi_day_gaps": cat_counts.get("multi_day_gap", 0),
                    "overnight_breaks": cat_counts.get("overnight_break", 0),
                    "weekend_gaps": cat_counts.get("weekend", 0),
                    "output_file": rep["output_file"]}
            summary_rows.append(flat)
            print(f"[{tf}] rows={rep['rows']} dup={info['duplicate_timestamps_found']} invalid={info['rows_dropped_invalid_candles']}")

    cons, mm = tf_consistency(frames)
    h1 = frames["H1"]
    prof = h1.assign(hour=h1["time"].dt.hour, rng=h1["high"] - h1["low"])
    hourly = prof.groupby("hour").agg(bars=("rng", "size"), mean_range=("rng", "mean"), median_range=("rng", "median"),
                                      mean_tick_volume=("tick_volume", "mean"))
    kn = prof[prof["spread_known"] == 1].groupby("hour")["spread"].median().rename("median_known_spread_points")
    hourly = hourly.join(kn).reset_index().rename(columns={"hour": "server_hour"})
    dow = prof.assign(dow=prof["time"].dt.dayofweek).groupby("dow").agg(bars=("rng", "size"), mean_range=("rng", "mean")).reset_index()
    yr = frames["M5"].assign(year=frames["M5"]["time"].dt.year).groupby("year").agg(
        m5_bars=("spread", "size"), spread_zero_share=("spread", lambda s: float((s == 0).mean())),
        median_known_spread=("spread", lambda s: float(s[s > 0].median()) if (s > 0).any() else np.nan)).reset_index()

    gaps_all = pd.concat(all_gaps, ignore_index=True)
    unexpected = gaps_all[gaps_all["category"].isin(["same_day_missing_bars", "multi_day_gap"])]
    report = {
        "report": "XAUUSD data quality report", "dataset_version": C.DATASET_VERSION,
        "source_archive": {"path": os.path.relpath(C.SOURCE_ZIP, C.ROOT), "sha256": src_sha,
                           "bytes": os.path.getsize(C.SOURCE_ZIP), "members": zip_listing,
                           "unchanged": "opened read-only; never extracted over or rewritten"},
        "timestamp_status": {"kept_unchanged": True, "convention": "MT5 bar OPEN time, naive broker-server clock",
                             "timezone": "UNVERIFIED", "diagnostics": timezone_diagnostics(frames["H1"])},
        "timeframes": tf_reports,
        "cross_timeframe_consistency_vs_M5": cons,
        "cross_timeframe_mismatch_rows_listed": int(len(mm)),
        "rejected_rows_total": int(sum(len(r) for r in rejected)),
        "unexpected_gap_rows": int(len(unexpected)),
        "gap_totals_by_category": {tf: tf_reports[tf]["gaps"]["by_category"] for tf in C.TF_ORDER},
    }
    rp = C.DIR_REPORTS
    with open(os.path.join(rp, "XAUUSD_data_quality_report.json"), "w") as f:
        json.dump(report, f, indent=2, default=str)
    pd.DataFrame(summary_rows).to_csv(os.path.join(rp, "XAUUSD_data_quality_summary.csv"), index=False, lineterminator="\n")
    pd.DataFrame(cons).to_csv(os.path.join(rp, "XAUUSD_timeframe_consistency.csv"), index=False, lineterminator="\n")
    unexpected.to_csv(os.path.join(rp, "XAUUSD_gaps_unexpected.csv"), index=False, lineterminator="\n")
    gaps_all.groupby(["timeframe", "category"]).agg(count=("gap_minutes", "size"), total_missing_slots=("missing_grid_slots", "sum"),
                                                    max_gap_minutes=("gap_minutes", "max")).reset_index().to_csv(
        os.path.join(rp, "XAUUSD_gaps_summary.csv"), index=False, lineterminator="\n")
    hourly.to_csv(os.path.join(rp, "XAUUSD_H1_hourly_profile_server_time.csv"), index=False, lineterminator="\n")
    dow.to_csv(os.path.join(rp, "XAUUSD_H1_weekday_profile.csv"), index=False, lineterminator="\n")
    yr.to_csv(os.path.join(rp, "XAUUSD_M5_spread_by_year.csv"), index=False, lineterminator="\n")
    if len(mm):
        mm.to_csv(os.path.join(rp, "XAUUSD_timeframe_consistency_mismatches.csv"), index=False, lineterminator="\n")
    if rejected:
        pd.concat(rejected).to_csv(os.path.join(rp, "XAUUSD_rejected_rows.csv"), index=False, lineterminator="\n")
    print("stage 1 done")


if __name__ == "__main__":
    main()
